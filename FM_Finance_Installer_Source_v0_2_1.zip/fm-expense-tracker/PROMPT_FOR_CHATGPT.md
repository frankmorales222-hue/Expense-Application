# Prompt for ChatGPT — F&M Finance v0.2.0

Attach `FM_Finance_Source_v0_2_0.zip` and paste everything below the line.

---

I'm attaching the source code for **F&M Finance v0.2.0**, an expense tracker for my company. This is a **working, tested codebase**. It is the baseline we build on from now on. Do **not** rewrite it, restructure it, replace the stack, or go back to the v0.1 prototype.

**What's verified already:**
- 31 backend tests pass against real PostgreSQL (`backend/tests`)
- The React frontend builds cleanly under TypeScript strict mode
- The app ran end to end: migrations, admin creation, login, creating an expense, uploading and downloading a receipt through an S3-compatible server, reports, and SPA deep links
- A PyInstaller build of `packaging/fm_expense_tracker.spec` was tested on Linux: started from a different working directory, it read `.env` from the executable's folder, ran migrations from inside the bundle, and served the frontend

**Stack (fixed):** Python 3.11+, FastAPI, SQLAlchemy 2, Alembic, psycopg2, PostgreSQL, MinIO via boto3, React 18 + TypeScript + Vite, PyInstaller one-folder build, NSSM Windows service. Read `README.md` first; it explains the layout, build, and deployment.

## Your task right now

1. Read the whole project, starting with `README.md`, `backend/app/main.py`, `backend/app/bootstrap.py`, and `packaging/fm_expense_tracker.spec`.
2. Confirm back to me, in a short list, what the app does and how it is built and deployed. Don't change anything yet.
3. Then help me build it on Windows with `packaging\build.bat` and run it for the first time. If the build or first run fails, I'll paste the exact error; fix the cause with the smallest possible change.

## Rules for every change you make from now on

1. **Keep the existing structure and stack.** No new frameworks or libraries unless I approve them first. Never add Redux, Tailwind, Next.js, Django, or an ORM other than SQLAlchemy.
2. **Database changes go in a new Alembic migration** in `backend/alembic/versions/` (`0002_...`, `0003_...`). Never edit `0001_initial.py`, and never use `Base.metadata.create_all`.
3. **Money stays `Decimal`** on the backend and is serialized as a JSON number through the `Money` type in `schemas.py`. Dates stay `YYYY-MM-DD` strings in the frontend; never pass them through `new Date()` for display.
4. **Every create, update, status change, and delete writes an audit entry** via `audit.record()` in the same transaction.
5. **Every endpoint except `/api/health` and `/api/auth/login` requires login** via `current_user` or `require_roles`.
6. **Receipts stay private.** They are streamed through `/api/receipts/{id}/content`; never return public or presigned MinIO URLs to the browser.
7. **Don't weaken security**: keep Argon2 hashing, the httpOnly cookie, login throttling, file-signature checks on uploads, safe filenames, CSV formula escaping, and the security headers.
8. **Tests must keep passing.** Add or update tests in `backend/tests/` for any backend change, and keep `npm run build` passing with no TypeScript errors.
9. **Bump the version** in `backend/app/__init__.py` and `frontend/package.json` for each release, and update `README.md` if setup or behavior changes.

## How to deliver changes

- Before writing code, list every file you will add or change and why.
- Give me **complete files**, never fragments, "...", or "rest unchanged" comments.
- Say plainly if you could not run the tests or the build yourself, so I know what still needs checking.
- When the change set is large, package the full updated project as a zip.
