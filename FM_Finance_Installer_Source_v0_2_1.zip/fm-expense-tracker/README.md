# F&M Finance — Expense Tracker (v0.2.1)

Expense tracking for F&M IT Services: record expenses, attach receipts, track what's been paid and what the business owes you back, and see spending by category and month. Built to be extended with invoicing and bank sync later.

**Stack:** FastAPI + SQLAlchemy + Alembic (Python 3.11+), React 18 + TypeScript + Vite, PostgreSQL, MinIO, packaged with PyInstaller and run as a Windows service via NSSM.

---

## What it does

- Sign in (single admin account created on first start; roles `admin`, `approver`, `submitter` are ready for later)
- Add, edit, and delete expenses (date, vendor with autocomplete, category, amount, description, payment method, reimbursable flag, notes)
- Attach receipts (PDF, JPG, PNG, HEIC up to 10 MB). Files are checked by content, not just extension, and stored in a private MinIO bucket. Receipts are streamed through the app, so MinIO never needs to be reachable from other computers.
- Status workflow: approved → paid (and undo). With `APPROVAL_REQUIRED=true`, amounts at or above a category's threshold start as pending and need approval.
- Full history of every change on each expense (audit log)
- Expense list with search, filters, sorting, paging, a filtered total, and CSV export
- Dashboard: total spent, owed back to you, spending by category, last 12 months
- Settings: add/rename/reorder/hide categories, per-category approval thresholds, change password

---

## Prerequisites

| Needed for | Software |
|---|---|
| Building | Python 3.11+ (tick "Add python.exe to PATH"), Node.js 20 LTS+ |
| Running | PostgreSQL 14+, MinIO, [NSSM](https://nssm.cc) for the Windows service |

### Create the database

```sql
CREATE USER fm_user WITH PASSWORD 'choose-a-strong-password';
CREATE DATABASE fm_finance OWNER fm_user;
```

The app creates all tables itself on first start. The `pgcrypto` extension is enabled by the first migration; if `fm_user` isn't allowed to create extensions, run `CREATE EXTENSION pgcrypto;` once in `fm_finance` as a superuser.

### MinIO

Create an access key for the app. The `expenses` bucket is created automatically (private) on first start.

---

## Windows setup installer (v0.2.1)

This release adds packaging and launch scripts; the v0.2.0 application behavior,
backend structure, database schema and runtime dependencies remain unchanged.

### Build the distributable installer

On a **64-bit Windows 10/11 build computer**, install Python 3.11+ (64-bit),
Node.js 20+, and **Inno Setup 6.3+** from https://jrsoftware.org/isdl.php.
Inno Setup is a packaging tool only; it is not an application runtime dependency.
The build downloads npm and pip dependencies, so it needs internet access.

Open Command Prompt in the project root and run:

```bat
packaging\build_installer.bat
```

This calls the existing `packaging\build.bat`, then compiles `packaging\installer.iss`.
Output: **`installer-output\FM_Finance_Setup_v0.2.1.exe`**.
Distribute that setup EXE. The destination computer needs neither Python nor Node.
The setup is unsigned; signing for public distribution requires your own certificate.
Do not disable Windows security to run it. The source ZIP is not a compiled installer.

### Install and first launch

1. Ensure PostgreSQL 14+ and MinIO are running, locally or on accessible servers.
   Create the database/user using the instructions below and obtain MinIO app keys.
   These services are **not bundled or installed** by this setup.
2. Run the generated setup EXE. It installs for the current Windows user under
   `%LOCALAPPDATA%\Programs\FM Finance`, creates a Start Menu shortcut, and offers
   a desktop shortcut and launch after setup. Choose a folder writable by that user.
3. First launch displays three configuration tabs for PostgreSQL, MinIO, and the
   administrator. Secrets are masked, PostgreSQL credentials are URL-encoded, and
   a cryptographically random JWT secret is generated automatically. The wizard
   creates `.env` only if it does not already exist. It does not test credentials;
   actual connection/migration validation happens when the application starts.
4. The app starts on localhost port 8010. Its normal bootstrap runs migrations,
   creates the first admin and default categories, and initializes receipt storage.
   The launcher opens your browser once the health endpoint reports the database
   ready. Storage can be degraded; receipts remain unavailable until MinIO works.
5. Sign in and change your password in Settings. Test an expense and receipt.
   The tray icon can reopen the browser or exit the local app. Closing the browser
   does not stop the server. Logging off stops this desktop launch; use NSSM for
   unattended server operation.

The **Configure F&M Finance** Start Menu entry opens the same configuration tool.
If `.env` exists it is preserved; close the app/stop the service and edit `.env`
for subsequent connection changes. Changing ADMIN_INITIAL_PASSWORD does not reset
an existing account. The wizard initially binds only to `127.0.0.1`; for shared
network use follow the HTTPS section below. Normal launches use the configured
APP_PORT (default 8010) and open a local HTTP URL; HTTPS proxy deployments should
use their HTTPS URL directly in the browser.

### Updates and removal

Close the app using its tray icon before installing an update. If using NSSM,
stop the service first, back up PostgreSQL, run the installer against the same
installation folder, then restart the service. Keep the same Windows account
for this per-user installer. `.env` and logs are excluded from the payload and
are preserved. Migrations still run on application start.

Uninstall via Windows Installed Apps or the Start Menu entry. For NSSM deployments,
run `uninstall_service.bat` as administrator first. Uninstall does not remove an
NSSM service automatically. It removes installed program files and shortcuts;
`.env`, logs, PostgreSQL data and MinIO receipts remain. Delete retained configuration
separately only when you intend to remove it. Stop/remove the NSSM service before
unattended uninstall as well.

### Validation status

This installer package was prepared on Linux. Windows batch execution, PowerShell
GUI/tray behavior, Inno Setup compilation, the Windows PyInstaller executable,
and the install/upgrade/uninstall flow have **not been executed here**. The
PostgreSQL backend suite and React build have not been rerun for this packaging
release. The baseline verification described by the owner applies to v0.2.0.

Before distribution, on Windows: build the installer; install on a clean user
profile; configure with actual services; log in; create/edit an expense; upload,
open and remove a receipt; use mark-paid/undo; refresh a deep link; exit from the
tray; reinstall over the same folder and verify configuration/data; then uninstall
and verify data retention. Separately verify NSSM service mode if you use it.
Run the original backend tests only against a disposable PostgreSQL database,
and confirm `npm run build` (also executed by build_installer.bat).

## Build the .exe (Windows)

From the project folder:

```bat
packaging\build.bat
```

Output: `dist\FMExpenseTracker\FMExpenseTracker.exe`, plus `.env.example` and the two service scripts in the same folder.

## First run

1. In `dist\FMExpenseTracker\`, copy `.env.example` to `.env` and fill in every `CHANGE_ME` value. Generate `JWT_SECRET` with `python -c "import secrets; print(secrets.token_urlsafe(48))"`.
2. Double-click `FMExpenseTracker.exe` (or run it from a command prompt to watch the log).
3. Open `http://localhost:8010` and sign in with `ADMIN_EMAIL` / `ADMIN_INITIAL_PASSWORD`.
4. Go to **Settings** and change your password.

If something is wrong (database unreachable, missing secret), the app stops with a plain-English message. Logs are in the `logs` folder next to the .exe.

## Install as a Windows service

1. Copy the whole `dist\FMExpenseTracker` folder to the server, e.g. `C:\Program Files\FM Finance\`.
2. Make sure `.env` is in that folder and `nssm.exe` is on PATH or in the same folder.
3. Right-click `install_service.bat` → **Run as administrator**.

The service starts automatically (delayed, so PostgreSQL and MinIO come up first) and restarts if it crashes. Remove it with `uninstall_service.bat`.

### Network access and HTTPS

With `APP_HOST=0.0.0.0` other computers can reach the app on port 8010 (open it in Windows Firewall). Over plain HTTP the login cookie travels unencrypted on the network, so for anything beyond your own machine put it behind HTTPS (IIS with URL Rewrite/ARR, or Caddy) and set `COOKIE_SECURE=true`. If you only use it on the server itself, set `APP_HOST=127.0.0.1`.

## Updating to a new version

1. Stop the service: `nssm stop FMExpenseTracker`
2. Back up the database (`pg_dump`).
3. Replace everything in the install folder **except** `.env` and `logs\`.
4. Start the service: `nssm start FMExpenseTracker`

Database migrations run automatically on start.

---

## Development

```bat
rem Backend (from the project root, with .env in the project root and APP_ENV=development)
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r backend\requirements-dev.txt
cd backend
..\.venv\Scripts\python.exe run.py

rem Frontend, in a second window (proxies /api to http://localhost:8010)
cd frontend
npm ci
npm run dev
```

Open `http://localhost:5173`. API docs are at `http://localhost:8010/api/docs` when `APP_ENV=development`.

### Tests

The tests run against a real PostgreSQL database, which they **wipe**. Point them at a throwaway database:

```bat
set TEST_DATABASE_URL=postgresql+psycopg2://fm_user:password@localhost:5432/fm_finance_test
cd backend
..\.venv\Scripts\python.exe -m pytest -q
```

### Database changes

Add a new migration instead of editing `0001_initial.py`:

```bat
cd backend
..\.venv\Scripts\alembic.exe revision -m "add invoices table"
```

---

## Project layout

```
backend/
  app/
    main.py          FastAPI app, security headers, SPA serving
    bootstrap.py     Startup: logging, config check, migrations, admin user, categories, storage
    config.py        Settings from .env (next to the .exe)
    paths.py         Dev vs. PyInstaller path handling
    models.py        SQLAlchemy models
    schemas.py       Request/response models (money serialized as numbers)
    security.py      Argon2, JWT cookie, roles, login throttling
    storage.py       MinIO client
    audit.py         Audit log helper
    routers/         auth, expenses, receipts, categories, vendors, reports, meta (health/settings)
  alembic/           Migrations (0001_initial.py)
  tests/             pytest suite
  run.py             Entry point
frontend/src/        React app (pages, components, api client)
packaging/           PyInstaller spec, build.bat, service scripts
```

## Manual test checklist

1. `packaging\build.bat` finishes with "Build complete".
2. Fill in `.env` in the dist folder, start the .exe, sign in.
3. Add an expense with a receipt, open the receipt, mark the expense paid.
4. Refresh the browser on an expense page (`/expenses/<id>`); it loads.
5. Install as a service, reboot, confirm the app comes back.
