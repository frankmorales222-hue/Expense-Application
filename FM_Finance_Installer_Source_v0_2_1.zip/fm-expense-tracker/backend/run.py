"""Entry point for development (`python run.py`) and for the PyInstaller executable."""

from __future__ import annotations

import sys


def main() -> int:
    from app.bootstrap import StartupError, startup

    try:
        settings = startup()
    except StartupError as exc:
        print(f"\nF&M Finance could not start:\n  {exc}\n", file=sys.stderr)
        return 1

    import uvicorn

    from app.main import create_app

    # Pass the app object (not an import string) so this works inside PyInstaller.
    uvicorn.run(create_app(), host=settings.APP_HOST, port=settings.APP_PORT,
                log_config=None, proxy_headers=True, forwarded_allow_ips="127.0.0.1")
    return 0


if __name__ == "__main__":
    sys.exit(main())
