# F&M Finance — Expense Tracker (v0.2.0)

Expense tracking for F&M IT Services: record expenses, attach receipts, track what's been paid and what the business owes you back, and see spending by category and month. Built to be extended with invoicing and bank sync later.

**Stack:** FastAPI + SQLAlchemy + Alembic (Python 3.11+), React 18 + TypeScript + Vite, PostgreSQL, MinIO, packaged with PyInstaller and run as a Windows service via NSSM.

---

## What it does

- Sign in (single admin account created on first start; roles `admin`, `approver`, `submitter` are ready for later)
- Add, edit, and delete expenses (date, vendor with autocomplete, category, amount, description, payment method, reimbursable flag, notes)
- Attach receipts (PDF, JPG, PNG, HEIC up to 10 MB). Files are checked by content, not just extension, and stored in a private MinIO bucket. Receipts are streamed through the app, so MinIO never needs to be reachable from other computers.
- Status workflow: approved → paid (and undo). With `APPROVAL_REQUIRED=true`, amounts at or above a category's threshold start as pending and need approval.
- Full history of every change on each expense (audit log)
- Expense list with search, filters, sorting, paging, a filtered total, and CSV export
- Dashboard: total spent, owed back to you, spending by category, last 12 months
- Settings: add/rename/reorder/hide categories, per-category approval thresholds, change password

---

## Prerequisites

| Needed for | Software |
|---|---|
| Building | Python 3.11+ (tick "Add python.exe to PATH"), Node.js 20 LTS+ |
| Running | PostgreSQL 14+, MinIO, [NSSM](https://nssm.cc) for the Windows service |

### Create the database

```sql
CREATE USER fm_user WITH PASSWORD 'choose-a-strong-password';
CREATE DATABASE fm_finance OWNER fm_user;
```

The app creates all tables itself on first start. The `pgcrypto` extension is enabled by the first migration; if `fm_user` isn't allowed to create extensions, run `CREATE EXTENSION pgcrypto;` once in `fm_finance` as a superuser.

### MinIO

Create an access key for the app. The `expenses` bucket is created automatically (private) on first start.

---

## Build the .exe (Windows)

From the project folder:

```bat
packaging\build.bat
```

Output: `dist\FMExpenseTracker\FMExpenseTracker.exe`, plus `.env.example` and the two service scripts in the same folder.

## First run

1. In `dist\FMExpenseTracker\`, copy `.env.example` to `.env` and fill in every `CHANGE_ME` value. Generate `JWT_SECRET` with `python -c "import secrets; print(secrets.token_urlsafe(48))"`.
2. Double-click `FMExpenseTracker.exe` (or run it from a command prompt to watch the log).
3. Open `http://localhost:8010` and sign in with `ADMIN_EMAIL` / `ADMIN_INITIAL_PASSWORD`.
4. Go to **Settings** and change your password.

If something is wrong (database unreachable, missing secret), the app stops with a plain-English message. Logs are in the `logs` folder next to the .exe.

## Install as a Windows service

1. Copy the whole `dist\FMExpenseTracker` folder to the server, e.g. `C:\Program Files\FM Finance\`.
2. Make sure `.env` is in that folder and `nssm.exe` is on PATH or in the same folder.
3. Right-click `install_service.bat` → **Run as administrator**.

The service starts automatically (delayed, so PostgreSQL and MinIO come up first) and restarts if it crashes. Remove it with `uninstall_service.bat`.

### Network access and HTTPS

With `APP_HOST=0.0.0.0` other computers can reach the app on port 8010 (open it in Windows Firewall). Over plain HTTP the login cookie travels unencrypted on the network, so for anything beyond your own machine put it behind HTTPS (IIS with URL Rewrite/ARR, or Caddy) and set `COOKIE_SECURE=true`. If you only use it on the server itself, set `APP_HOST=127.0.0.1`.

## Updating to a new version

1. Stop the service: `nssm stop FMExpenseTracker`
2. Back up the database (`pg_dump`).
3. Replace everything in the install folder **except** `.env` and `logs\`.
4. Start the service: `nssm start FMExpenseTracker`

Database migrations run automatically on start.

---

## Development

```bat
rem Backend (from the project root, with .env in the project root and APP_ENV=development)
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r backend\requirements-dev.txt
cd backend
..\.venv\Scripts\python.exe run.py

rem Frontend, in a second window (proxies /api to http://localhost:8010)
cd frontend
npm ci
npm run dev
```

Open `http://localhost:5173`. API docs are at `http://localhost:8010/api/docs` when `APP_ENV=development`.

### Tests

The tests run against a real PostgreSQL database, which they **wipe**. Point them at a throwaway database:

```bat
set TEST_DATABASE_URL=postgresql+psycopg2://fm_user:password@localhost:5432/fm_finance_test
cd backend
..\.venv\Scripts\python.exe -m pytest -q
```

### Database changes

Add a new migration instead of editing `0001_initial.py`:

```bat
cd backend
..\.venv\Scripts\alembic.exe revision -m "add invoices table"
```

---

## Project layout

```
backend/
  app/
    main.py          FastAPI app, security headers, SPA serving
    bootstrap.py     Startup: logging, config check, migrations, admin user, categories, storage
    config.py        Settings from .env (next to the .exe)
    paths.py         Dev vs. PyInstaller path handling
    models.py        SQLAlchemy models
    schemas.py       Request/response models (money serialized as numbers)
    security.py      Argon2, JWT cookie, roles, login throttling
    storage.py       MinIO client
    audit.py         Audit log helper
    routers/         auth, expenses, receipts, categories, vendors, reports, meta (health/settings)
  alembic/           Migrations (0001_initial.py)
  tests/             pytest suite
  run.py             Entry point
frontend/src/        React app (pages, components, api client)
packaging/           PyInstaller spec, build.bat, service scripts
```

## Manual test checklist

1. `packaging\build.bat` finishes with "Build complete".
2. Fill in `.env` in the dist folder, start the .exe, sign in.
3. Add an expense with a receipt, open the receipt, mark the expense paid.
4. Refresh the browser on an expense page (`/expenses/<id>`); it loads.
5. Install as a service, reboot, confirm the app comes back.
