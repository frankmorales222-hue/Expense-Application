# F&M Finance v0.10.0: build handoff for ChatGPT

I'm attaching FM_Finance_v0_10_0_source.zip. The source has been reviewed and tested.
Your job is packaging and build verification only: do NOT change application code (backend/app,
frontend/src, backend/alembic, backend/tests). If something fails, show me the exact error and
propose the smallest packaging-only fix before applying it.

## Build (same process as v0.9.0)
1. 64-bit Python 3.12 and Node 20+.
2. Frontend: `npm ci` then `npm run build` in frontend\. Only dependency change: react-router-dom is now
   6.30.6 (pinned, in package.json and package-lock.json). No new packages.
3. Install backend\requirements-portable.txt exactly as pinned, plus pyinstaller==6.22.3, pytest==8.3.4,
   httpx==0.28.1. No --upgrade. No new Python packages in v0.10.0.
4. Tests: in backend\, set TEST_DATABASE_URL=sqlite:///data/fm_finance_test.db and run pytest -q.
   Expected: 164 passed, 1 skipped.
5. Build with packaging\fm_finance_portable.spec. New hidden imports (already in both specs): app.rules,
   app.permissions, app.schema_rules, app.routers.rules, app.routers.bank_rules, app.routers.roles,
   app.routers.ruleutil.
6. `FMFinance.exe --selftest` must write selftest.txt starting with PASS.
7. Start the EXE from an empty folder with a prepared .env and check /api/health: version 0.10.0,
   database ok, storage ok.
Version is 0.10.0 everywhere (backend\app\__init__.py, frontend\package.json and package-lock.json,
packaging\installer.iss, packaging\build_installer.bat, .github\workflows\build-windows.yml). I already
searched the whole package for 0.9.0; the remaining mentions are comments about what v0.9.0 added. Do not
change the version.

## npm audit (expected, not a blocker)
`npm audit --omit=dev` reports 2 moderate React Router advisories that cover every 6.x release; the fix is
React Router 7, a major upgrade planned separately. Neither applies to this app: one is about server-side
rendering (not used), the other an open redirect through untrusted links (the only such path, the
return address after sign-in, is now checked). Report them; don't upgrade.

## Upgrade check
Copy my v0.9.0 data folder next to the new EXE (a COPY), start it, sign in and check:
- The log shows "Running upgrade 0020_sqlite_themes -> 0022_sqlite_rules" and no errors (this step
  rebuilds the expenses table once; that's expected).
- Settings > Books still says "Your books are in balance"; expenses, invoices, bills and customers are unchanged.
- Settings shows a "Company rules" card; it opens on Money and dates (USD, 1,234.56, MM/DD/YYYY).
- Administration > Plans and modules lists Starter, Essentials, Plus and Advanced, and every company keeps
  its plan.

## What changed in v0.10.0
Company rules: each company sets its own currency and formats, approvals, payment terms, payment methods,
custom fields (customers, items, invoices, bills, expenses), invoice numbering, PDF wording and color, invoice
email template, approve-all level and dashboard periods. Bank rules. Company-defined roles that narrow the
built-in ones. Plans stored as data and editable by the platform owner and resellers. Migrations 0022 (SQLite)
/ 0023 (PostgreSQL).

## Smoke test I will run on Windows (for reference when diagnosing)
- Settings > Company rules: add a term "10th of next month", Zelle as a received method and a "PO number"
  invoice field printed on the PDF; save. A new invoice offers the term and the PO field; the PDF shows it.
- Change numbers to 1.234,56 and dates to DD/MM/YYYY: amounts and dates change on every screen and the PDF.
- Turn approvals on at 750: a $1,000 expense waits for approval.
- Banking > Bank rules: a rule for MICROSOFT with "Approve automatically"; importing a statement approves it.
- Team: a Front desk role (Bookkeeper without Banking); a person with it doesn't see Banking and gets
  "not allowed" if they try.
- Plans and modules: add a plan, put a company on it.
- Everything from v0.9.0 still works (themes, dashboard, invoices, payments, bills, email).

Deliver: portable-output\FMFinance.exe, the build log, the test summary, selftest.txt and the upgrade
check result.
