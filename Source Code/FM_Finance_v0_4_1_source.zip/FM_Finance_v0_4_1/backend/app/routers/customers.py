from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import audit
from ..database import get_db
from ..models import Customer, User
from ..schemas import CustomerIn, CustomerOut
from ..security import require_roles
from .util import current_company

router = APIRouter(prefix="/api/customers", tags=["customers"])


@router.get("", response_model=list[CustomerOut])
def list_customers(include_inactive: bool = False, db: Session = Depends(get_db),
                   _: User = Depends(require_roles("admin", "approver"))) -> list[Customer]:
    stmt = select(Customer).where(Customer.company_id == current_company(db).id)
    if not include_inactive:
        stmt = stmt.where(Customer.is_active.is_(True))
    return list(db.scalars(stmt.order_by(Customer.name)))


def _unique(db: Session, company_id: uuid.UUID, name: str, exclude: uuid.UUID | None = None) -> None:
    stmt = select(Customer.id).where(Customer.company_id == company_id, func.lower(Customer.name) == name.lower())
    if exclude:
        stmt = stmt.where(Customer.id != exclude)
    if db.scalar(stmt):
        raise HTTPException(status.HTTP_409_CONFLICT, "A customer with that name already exists")


@router.post("", response_model=CustomerOut, status_code=status.HTTP_201_CREATED)
def create_customer(payload: CustomerIn, db: Session = Depends(get_db),
                    user: User = Depends(require_roles("admin", "approver"))) -> Customer:
    company = current_company(db)
    _unique(db, company.id, payload.name)
    customer = Customer(company_id=company.id, **payload.model_dump())
    db.add(customer)
    db.flush()
    audit.record(db, entity_type="customer", entity_id=customer.id, action="created", user_id=user.id,
                 changes={"name": customer.name})
    db.commit()
    return customer


@router.put("/{customer_id}", response_model=CustomerOut)
def update_customer(customer_id: uuid.UUID, payload: CustomerIn, db: Session = Depends(get_db),
                    user: User = Depends(require_roles("admin", "approver"))) -> Customer:
    customer = db.get(Customer, customer_id)
    if customer is None or customer.company_id != current_company(db).id:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Customer not found")
    _unique(db, customer.company_id, payload.name, exclude=customer.id)
    changes = {}
    for field, value in payload.model_dump().items():
        if getattr(customer, field) != value:
            changes[field] = [getattr(customer, field), value]
            setattr(customer, field, value)
    if changes:
        audit.record(db, entity_type="customer", entity_id=customer.id, action="updated", user_id=user.id,
                     changes=changes)
        db.commit()
    return customer
