# F&M Finance v0.4.1: build handoff for ChatGPT

I'm attaching FM_Finance_v0_4_1_source.zip. The source has been reviewed and tested.
Your job is packaging and build diagnosis only: do NOT change application code (backend/app,
frontend/src, backend/alembic, backend/tests). If something fails, show me the exact error and
propose the smallest packaging-only fix before applying it.

## How the EXE is built
Your environment can't build Windows EXEs (Linux, no Wine, no internet), so the Windows build runs
on GitHub Actions: .github/workflows/build-windows.yml. On a GitHub Windows runner it:
1. checks for 64-bit Python 3.12 and Node 20,
2. builds the frontend (npm ci, npm run build),
3. installs backend\requirements-portable.txt exactly as pinned plus pyinstaller==6.22.3,
4. runs the test suite (expected: all pass, 1 skipped),
5. builds portable-output\FMFinance.exe with packaging\fm_finance_portable.spec,
6. runs `FMFinance.exe --selftest` (PDF, Word, email and OCR readers inside the EXE; expects PASS),
7. starts the EXE with a prepared .env and checks /api/health reports version 0.4.1, database ok,
8. uploads FMFinance.exe as the artifact "FMFinance-v0.4.1".

When I send you a failed run's log, find the failing step, explain the cause in plain words, and
propose a packaging-only fix (spec, workflow, build script or pins). The most likely areas in this
version are PyInstaller collecting the bill-reading packages: rapidocr_onnxruntime (its .onnx models
and config.yaml), onnxruntime (DLLs), pypdfium2/pypdfium2_raw (pdfium.dll), opencv-python and
extract_msg. The spec collects them with collect_all; numpy must NOT be excluded.

## Version
0.4.1 everywhere (backend/app/__init__.py, frontend/package.json and package-lock.json, installer.iss,
the workflow's health check and artifact name). Do not change it.

## Smoke test I will run on Windows (for reference when diagnosing)
- Settings > Company: upload a PNG logo; it appears in the sidebar and on the sign-in page. Remove brings back the default mark.
- First launch in an empty folder: first-run message box, .env, data\fm_finance.db, browser opens.
- Add expense > Fill this in from a bill with: a digital PDF invoice, a phone photo of a receipt,
  a Word invoice, and an email saved from Outlook (.msg). Fields fill in and the file is listed under
  Receipts; saving attaches it.
- With AI_EXTRACTION=fallback and an Anthropic key in .env, a blurry photo fills via "Read with AI".
- Banking still works (import a CSV twice: second import adds 0).
- "Exit app" stops the process; a second launch only opens the browser.

## Upgrading an existing install
Replace FMFinance.exe, keep .env and data\ (back up data\ first). Migrations run on start.
To enable AI reading, add to .env: AI_EXTRACTION=fallback and ANTHROPIC_API_KEY=<key>.

## Fix applied after the first v0.4.1 build attempt
The first build failed its health check with `ModuleNotFoundError: No module named 'app.schema_branding'`
(the 0008/0009 migrations import it at runtime). Both spec files now:
- list "app.schema_branding" in hiddenimports (your proposed fix), and
- add backend\ to sys.path and include collect_submodules("app"), so every app module, including
  future app.schema_* modules used only by migrations, is bundled automatically.
No application code changed. The version stays 0.4.1 because the faulty EXE was never delivered.
Rebuild and rerun the full verification (tests, --selftest, health check).
