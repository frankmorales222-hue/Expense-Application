export type ExpenseStatus = "pending" | "approved" | "paid" | "rejected";
export type PaymentMethod = "business_card" | "business_bank" | "personal_card" | "cash" | "other";

export interface User {
  id: string;
  email: string;
  name: string;
  role: "admin" | "approver" | "submitter";
}

export interface AppSettings {
  version: string;
  currency: string;
  approval_required: boolean;
  default_approval_threshold: number;
  max_receipt_mb: number;
  desktop_mode: boolean;
  receipt_storage: "local" | "minio";
  database: "sqlite" | "postgresql";
}

export interface Category {
  id: string;
  code: string;
  name: string;
  approval_threshold: number | null;
  is_active: boolean;
  sort_order: number;
  kind: CategoryKind;
  tax_line: string | null;
}

export type CategoryKind = "expense" | "income" | "equity";

export interface Vendor {
  id: string;
  name: string;
}

export interface ExpenseListItem {
  id: string;
  expense_date: string;
  vendor_name: string | null;
  category_id: string;
  category_name: string;
  description: string;
  amount: number;
  currency: string;
  payment_method: PaymentMethod | null;
  is_reimbursable: boolean;
  status: ExpenseStatus;
  receipt_count: number;
  created_at: string;
}

export interface Receipt {
  id: string;
  original_filename: string;
  content_type: string;
  size_bytes: number;
  uploaded_at: string;
}

export interface AuditEntry {
  id: string;
  action: string;
  user_name: string | null;
  changes: Record<string, unknown> | null;
  created_at: string;
}

export interface ExpenseDetail extends ExpenseListItem {
  notes: string | null;
  invoice_number: string | null;
  due_date: string | null;
  bank_transaction_id: string | null;
  approved_at: string | null;
  paid_at: string | null;
  receipts: Receipt[];
  history: AuditEntry[];
  allowed_transitions: ExpenseStatus[];
}

export interface ExpensePage {
  items: ExpenseListItem[];
  total: number;
  total_amount: number;
  page: number;
  page_size: number;
}

export interface ExpenseInput {
  expense_date: string;
  vendor_name: string | null;
  category_id: string;
  description: string;
  amount: number;
  payment_method: PaymentMethod | null;
  is_reimbursable: boolean;
  notes: string | null;
  invoice_number: string | null;
  due_date: string | null;
}

export interface NameAmount {
  key: string;
  label: string;
  amount: number;
  count: number;
}

export interface Summary {
  date_from: string | null;
  date_to: string | null;
  total_spent: number;
  expense_count: number;
  pending_count: number;
  pending_amount: number;
  reimbursable_owed: number;
  by_status: NameAmount[];
  by_category: NameAmount[];
  by_month: NameAmount[];
}

export interface ExpenseFilters {
  status?: ExpenseStatus | "";
  category_id?: string;
  date_from?: string;
  date_to?: string;
  search?: string;
  sort?: "date_desc" | "date_asc" | "amount_desc" | "amount_asc";
}

// ---------- Phase 1: banking ----------
export type AccountKind = "checking" | "savings" | "credit_card" | "cash" | "other";
export type ReviewStatus = "unreviewed" | "approved" | "excluded";
export type Tab = "review" | "approved" | "excluded" | "all";
export type TxnFlag = "transfer" | "duplicate" | "uncategorized" | "missing_receipt" | "money_in" | "money_out";

export interface Company {
  id: string;
  name: string;
  legal_name: string | null;
  base_currency: string;
  fiscal_year_start_month: number;
  has_logo: boolean;
  logo_version: number;
}

export interface Branding {
  name: string;
  has_logo: boolean;
  logo_version: number;
}

export interface Account {
  id: string;
  name: string;
  kind: AccountKind;
  institution: string | null;
  last4: string | null;
  currency: string;
  opening_balance: number;
  opening_date: string | null;
  is_active: boolean;
  balance: number;
  unreviewed_count: number;
  transaction_count: number;
  has_csv_profile: boolean;
}

export interface AccountInput {
  name: string;
  kind: AccountKind;
  institution: string | null;
  last4: string | null;
  opening_balance: number;
  opening_date: string | null;
  is_active: boolean;
}

export interface Customer {
  id: string;
  name: string;
  email: string | null;
  notes: string | null;
  is_active: boolean;
}

export interface CsvMapping {
  date_column: number | null;
  description_column: number | null;
  amount_column: number | null;
  debit_column: number | null;
  credit_column: number | null;
  invert_amounts: boolean;
  date_format: string | null;
}

export interface PreviewRow {
  line: number;
  txn_date: string | null;
  amount: number | null;
  description: string;
  error: string | null;
}

export interface ImportPreview {
  source: "csv" | "ofx";
  filename: string;
  total_rows: number;
  valid_rows: number;
  invalid_rows: number;
  date_from: string | null;
  date_to: string | null;
  money_in: number;
  money_out: number;
  rows: PreviewRow[];
  headers: string[];
  sample: string[][];
  mapping: CsvMapping | null;
  problems: string[];
  file_account_last4: string | null;
  previously_imported: boolean;
}

export interface ImportBatch {
  id: string;
  account_id: string;
  account_name: string;
  source: string;
  filename: string;
  rows_total: number;
  rows_imported: number;
  rows_duplicate: number;
  rows_invalid: number;
  rows_flagged: number;
  status: "active" | "undone";
  created_at: string;
  approved_count: number;
}

export interface PeerTxn {
  id: string;
  account_id: string;
  account_name: string;
  txn_date: string;
  amount: number;
  description: string;
  review_status: ReviewStatus;
}

export interface Txn {
  id: string;
  account_id: string;
  account_name: string;
  account_kind: AccountKind;
  txn_date: string;
  amount: number;
  description: string;
  normalized: string;
  memo: string | null;
  source: "csv" | "ofx" | "manual";
  review_status: ReviewStatus;
  category_id: string | null;
  category_name: string | null;
  vendor_id: string | null;
  vendor_name: string | null;
  customer_id: string | null;
  customer_name: string | null;
  suggested_category_id: string | null;
  suggested_category_name: string | null;
  suggested_vendor_name: string | null;
  confidence: number;
  suggestion_reason: string | null;
  is_transfer: boolean;
  transfer_peer: PeerTxn | null;
  duplicate_of: PeerTxn | null;
  expense_id: string | null;
  receipt_status: "attached" | "missing" | "not_needed";
  approved_at: string | null;
}

export interface TxnPage {
  items: Txn[];
  total: number;
  page: number;
  page_size: number;
  counts: { review: number; approved: number; excluded: number };
  total_in: number;
  total_out: number;
}

export interface TxnFilters {
  account_id?: string;
  tab: Tab;
  flag?: TxnFlag | "";
  search?: string;
  date_from?: string;
  date_to?: string;
  sort?: "date_desc" | "date_asc" | "amount_desc" | "amount_asc";
}

export interface TxnUpdate {
  category_id?: string | null;
  vendor_name?: string | null;
  customer_id?: string | null;
  memo?: string | null;
  expense_id?: string | null;
}

export interface ManualTxnInput {
  account_id: string;
  txn_date: string;
  amount: number;
  description: string;
  category_id: string | null;
  vendor_name: string | null;
  customer_id: string | null;
  memo: string | null;
}

export interface BulkResult {
  approved: number;
  skipped: number;
  messages: string[];
}

export interface Candidates {
  transfers: PeerTxn[];
  expenses: ExpenseListItem[];
}

// ---------- v0.4.0: bill import ----------
export interface BillCapabilities {
  ocr: boolean;
  ai_mode: "off" | "fallback" | "always";
  ai_requested: string;
  ai_key_set: boolean;
  ai_model: string;
  formats: string[];
}

export interface BillExtract {
  filename: string;
  method: "text" | "ocr" | "ai";
  vendor_name: string | null;
  expense_date: string | null;
  due_date: string | null;
  amount: number | null;
  invoice_number: string | null;
  description: string | null;
  currency: string;
  category_id: string | null;
  category_reason: string;
  confidence: Record<string, number>;
  sources: Record<string, string>;
  confident: boolean;
  known_vendor: boolean;
  warnings: string[];
  attachments: string[];
  text_preview: string;
  duplicates: ExpenseListItem[];
  bank_match: { id: string; account_name: string; txn_date: string; description: string } | null;
}
