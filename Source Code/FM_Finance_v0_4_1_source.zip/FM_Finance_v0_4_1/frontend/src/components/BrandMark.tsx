import { useEffect, useState } from "react";
import { api } from "../api";
import type { Branding } from "../types";

/** Company logo when one is uploaded; otherwise the default F&M mark. Refreshes after a logo change. */
export const BRANDING_CHANGED = "fm-branding-changed";

export default function BrandMark({ login = false }: { login?: boolean }) {
  const [brand, setBrand] = useState<Branding | null>(null);
  const [broken, setBroken] = useState(false);

  useEffect(() => {
    const load = () => api.branding().then((b) => { setBrand(b); setBroken(false); }).catch(() => setBrand(null));
    load();
    window.addEventListener(BRANDING_CHANGED, load);
    return () => window.removeEventListener(BRANDING_CHANGED, load);
  }, []);

  if (brand?.has_logo && !broken) {
    return (
      <div className={login ? "brand brand-login brand-has-logo" : "brand brand-has-logo"}>
        <img className="brand-logo" src={`/api/company/logo?v=${brand.logo_version}`} alt={brand.name}
          onError={() => setBroken(true)} />
      </div>
    );
  }
  return (
    <div className={login ? "brand brand-login" : "brand"}>
      <span className="brand-mark" aria-hidden="true">F&amp;M</span>
      <span className="brand-name">Finance</span>
    </div>
  );
}
