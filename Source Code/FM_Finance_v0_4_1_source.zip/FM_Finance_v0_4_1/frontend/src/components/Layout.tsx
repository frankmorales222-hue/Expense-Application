import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { api } from "../api";
import BrandMark from "./BrandMark";
import { useAuth, useToast } from "../context";

const NAV = [
  { to: "/", label: "Dashboard", end: true, banking: false },
  { to: "/banking", label: "Banking", end: false, banking: true },
  { to: "/expenses", label: "Expenses", end: true, banking: false },
  { to: "/expenses/new", label: "Add expense", end: true, banking: false },
  { to: "/accounts", label: "Accounts", end: true, banking: true },
  { to: "/settings", label: "Settings", end: true, banking: false },
];

export default function Layout() {
  const { user, settings, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [stopped, setStopped] = useState(false);
  const canBank = user?.role === "admin" || user?.role === "approver";

  async function signOut() {
    await logout();
    navigate("/login", { replace: true });
  }

  async function exitApp() {
    if (!window.confirm("Stop F&M Finance? You'll need to start FMFinance.exe again to use it.")) return;
    try {
      await api.shutdown();
      setStopped(true);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not stop the app");
    }
  }

  if (stopped) {
    return (
      <div className="login">
        <div className="login-card">
          <h1>F&amp;M Finance has stopped</h1>
          <p className="muted">Your data is saved. You can close this tab. Start FMFinance.exe to open it again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="shell">
      <aside className="sidebar">
        <BrandMark />
        <nav aria-label="Main">
          {NAV.filter((n) => canBank || !n.banking).map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div className="who">{user?.name}</div>
          <button type="button" className="link-button" onClick={() => void signOut()}>Sign out</button>
          {settings?.desktop_mode && user?.role === "admin" && (
            <button type="button" className="link-button danger" onClick={() => void exitApp()}>Exit app</button>
          )}
          {settings && <div className="version">v{settings.version}{settings.database === "sqlite" ? " (test database)" : ""}</div>}
        </div>
      </aside>
      <main className="main">
        <Outlet />
      </main>
    </div>
  );
}
