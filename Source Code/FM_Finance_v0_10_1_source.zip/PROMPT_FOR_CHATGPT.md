# F&M Finance v0.10.1: build handoff for ChatGPT (in-app updates)

I'm attaching FM_Finance_v0_10_1_source.zip. The source has been reviewed and tested.
Your job is packaging and build verification: do NOT change application code (backend/app, frontend/src,
backend/alembic, backend/tests). The ONE exception is backend\app\update_key.py, which the key tool below
writes. If something fails, show me the exact error and propose the smallest packaging-only fix first.

## Why this release
Until now every release was a new EXE that I installed by hand. From v0.10.1 the app installs updates
itself (Administration > Updates) from a signed file. Each release from now on produces TWO things:
- portable-output\FMFinance.exe: the full program, only for a brand-new PC.
- update-output\FMFinance_Update_v<version>.fmupdate: what I install from inside the app.
Always name the program FMFinance.exe. Put the version only in the update file's name (the build does this).
Don't make versioned copies like FMFinance_v0_10_1.exe.

## Step 1 (one time only): the update signing key
Run this BEFORE building, from the source folder, with the build's Python (.venv if it exists, else py -3.12):
    python packaging\make_update.py keygen
- It creates the PRIVATE key at %USERPROFILE%\.fmfinance\update_signing_key.pem and writes the matching
  PUBLIC key into backend\app\update_key.py.
- The private key must NEVER be put in a zip, uploaded, emailed or shown to me. Tell me where it is, and
  remind me to back it up (USB drive or password manager). If it's lost, installed copies can only take
  updates again after one manual install of a build with a new key.
- If a key already exists on this PC, keygen keeps it and only refreshes update_key.py. Never use --force
  unless I ask.
- After this step, show me the full contents of backend\app\update_key.py (it's a public key, safe to share).
  I'll put it in the source so every future zip carries it. Until then, a future zip may contain
  `PUBLIC_KEY_PEM = None`; that's expected, because build_portable.bat re-runs keygen before building and
  puts this PC's public key back.

## Step 2: build
packaging\build_portable.bat, the same process as v0.10.0 with one new final step:
1. 64-bit Python 3.12 and Node 20+. `npm ci`, `npm run build`. No dependency changes in v0.10.1.
2. requirements-portable.txt exactly as pinned, plus pyinstaller==6.22.3, pytest==8.3.4, httpx==0.28.1.
3. Tests: expected 181 passed, 1 skipped.
4. Before PyInstaller, the script runs `make_update.py keygen` (refreshes the public key in the source).
   New modules (app.updates, app.update_key, app.routers.updates) are picked up by
   collect_submodules("app") in the spec; nothing to add.
5. New step [5/5]: makes and verifies update-output\FMFinance_Update_v0.10.1.fmupdate.
6. `FMFinance.exe --selftest` writes selftest.txt starting with PASS.
7. /api/health shows version 0.10.1, and GET /api/health/version returns exactly `fm-finance:0.10.1:ok`.
Version is 0.10.1 everywhere (I checked the whole package). Don't change it.

## Step 3: test the updater on Windows (this part can only be tested on Windows)
Use a TEST folder with a COPY of my data, never my real install. Use port 8010 or whatever the copy's .env
says. If the UI automation still fails with spawn EPERM, do these through the API with PowerShell
(Invoke-WebRequest with a session: POST /api/auth/login, POST /api/updates/upload as multipart with field
"file", POST /api/updates/apply, then poll GET /api/health/version) and read the files listed.

a) Setup: copy the new portable-output\FMFinance.exe into the test folder (this one time by hand), start it,
   sign in as the administrator. Administration > Updates shows version 0.10.1 and "Install an update".
b) Reinstall (the success path): upload update-output\FMFinance_Update_v0.10.1.fmupdate. It shows
   "Reinstall version 0.10.1". Click "Reinstall and restart". Expected within about 1 minute:
   - the app closes and starts again by itself, with no second browser tab opened;
   - the page reloads and Updates shows "Version 0.10.1 was installed";
   - FMFinance.previous.exe exists, backups\before-v0.10.1-<date>\ has fm_finance.db and .env;
   - updates\last_result.txt says status=ok and updates\update.log ends with "Update to 0.10.1 finished".
c) Roll-back (the safety net): make a deliberately wrong test file:
       python packaging\make_update.py build --version 0.10.99 --out update-test
   Upload update-test\FMFinance_Update_v0.10.99.fmupdate and install. The program inside reports 0.10.1, so
   the helper must give up after about 2 minutes and put the previous program and the database back.
   Expected: the app is running again as 0.10.1, Updates shows "didn't start… put back", last_result.txt
   says status=rolled_back, and Settings > Books is still in balance. Then DELETE the update-test folder.
   It must never be shipped.
d) Refusals: (1) copy FMFinance.exe, rename it test.fmupdate and upload it: refused. (2) Open a copy of the
   real .fmupdate in a zip tool, replace manifest.json's notes with any text, and upload it: refused as not
   signed. Nothing staged in either case.
e) Folder with spaces and parentheses: repeat (b) once from a folder named like
   "C:\Temp\FM Finance (test)". It must work the same.
Report each of a) to e) with what you saw and the last lines of updates\update.log.

## How I'll move my real install over (for your information)
v0.10.0 doesn't have the updater, so I'll replace my FMFinance.exe with the new one by hand ONE last time
(same folder, same name, after stopping the app and backing up the data folder). From then on, every release
is just the .fmupdate file installed from Administration > Updates.

## Deliverables
portable-output\FMFinance.exe, update-output\FMFinance_Update_v0.10.1.fmupdate, the build log, the test
summary, selftest.txt, the contents of backend\app\update_key.py, where the private key is stored, and the
results of the Step 3 tests (a to e).
