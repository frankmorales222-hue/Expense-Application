import type {
  Account, AccountInput, AppSettings, BillCapabilities, BillExtract, Branding, CompanyListItem, CompanyRole, Member,
  Reseller, ResellerAdmin, BulkResult, Candidates, Category, CategoryKind, Company, CsvMapping,
  Customer, ExpenseDetail, ExpenseFilters, ExpenseInput, ExpensePage, ExpenseStatus, ImportBatch, ImportPreview,
  ManualTxnInput, Receipt, Summary, Txn, TxnFilters, TxnPage, TxnUpdate, User, Vendor,
} from "./types";

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

interface ValidationIssue {
  loc?: (string | number)[];
  msg?: string;
}

function errorMessage(data: unknown, fallback: string): string {
  if (data && typeof data === "object" && "detail" in data) {
    const detail = (data as { detail: unknown }).detail;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) {
      return (detail as ValidationIssue[])
        .map((d) => {
          const field = d.loc ? String(d.loc[d.loc.length - 1]).replace(/_/g, " ") : "";
          return field ? `${field}: ${d.msg ?? "invalid"}` : d.msg ?? "invalid";
        })
        .join("; ");
    }
  }
  return fallback;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && !(init.body instanceof FormData)) headers.set("Content-Type", "application/json");
  const res = await fetch(`/api${path}`, { ...init, headers, credentials: "same-origin" });
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!res.ok) {
    if (res.status === 401 && path !== "/auth/login") window.dispatchEvent(new Event("fm:unauthorized"));
    throw new ApiError(res.status, errorMessage(data, `Request failed (${res.status})`));
  }
  return data as T;
}

const json = (body: unknown): RequestInit => ({ body: JSON.stringify(body) });

function query(params: Record<string, string | number | undefined | null>): string {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
  const s = q.toString();
  return s ? `?${s}` : "";
}

export const api = {
  login: (email: string, password: string) => request<User>("/auth/login", { method: "POST", ...json({ email, password }) }),
  logout: () => request<void>("/auth/logout", { method: "POST" }),
  me: () => request<User>("/auth/me"),
  changePassword: (current_password: string, new_password: string) =>
    request<void>("/auth/change-password", { method: "POST", ...json({ current_password, new_password }) }),
  settings: () => request<AppSettings>("/settings"),

  categories: (includeInactive = false) => request<Category[]>(`/categories${query({ include_inactive: includeInactive ? "true" : undefined })}`),
  createCategory: (name: string, approval_threshold: number | null, kind: CategoryKind = "expense") =>
    request<Category>("/categories", { method: "POST", ...json({ name, approval_threshold, kind }) }),
  updateCategory: (id: string, body: Partial<Pick<Category, "name" | "is_active" | "sort_order" | "kind" | "tax_line">> & { approval_threshold?: number; clear_threshold?: boolean }) =>
    request<Category>(`/categories/${id}`, { method: "PUT", ...json(body) }),

  vendors: (q: string) => request<Vendor[]>(`/vendors${query({ q })}`),

  listExpenses: (f: ExpenseFilters, page = 1, pageSize = 25) =>
    request<ExpensePage>(`/expenses${query({ ...f, page, page_size: pageSize })}`),
  exportUrl: (f: ExpenseFilters) => `/api/expenses/export.csv${query({ ...f })}`,
  getExpense: (id: string) => request<ExpenseDetail>(`/expenses/${id}`),
  createExpense: (body: ExpenseInput) => request<ExpenseDetail>("/expenses", { method: "POST", ...json(body) }),
  updateExpense: (id: string, body: ExpenseInput) => request<ExpenseDetail>(`/expenses/${id}`, { method: "PUT", ...json(body) }),
  setStatus: (id: string, status: ExpenseStatus, note?: string) =>
    request<ExpenseDetail>(`/expenses/${id}/status`, { method: "POST", ...json({ status, note }) }),
  deleteExpense: (id: string) => request<void>(`/expenses/${id}`, { method: "DELETE" }),

  uploadReceipt: (expenseId: string, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<Receipt>(`/expenses/${expenseId}/receipts`, { method: "POST", body: form });
  },
  receiptUrl: (id: string) => `/api/receipts/${id}/content`,
  deleteReceipt: (id: string) => request<void>(`/receipts/${id}`, { method: "DELETE" }),

  summary: (date_from?: string, date_to?: string) => request<Summary>(`/reports/summary${query({ date_from, date_to })}`),

  // ---------- companies, team, resellers ----------
  companies: () => request<CompanyListItem[]>("/companies"),
  switchCompany: (id: string) => request<User>(`/companies/${id}/switch`, { method: "POST" }),
  createCompany: (body: { name: string; legal_name: string | null; reseller_id: string | null }) =>
    request<CompanyListItem>("/companies", { method: "POST", ...json(body) }),
  members: () => request<Member[]>("/members"),
  addMember: (body: { email: string; name: string | null; role: CompanyRole }) =>
    request<{ member: Member; temporary_password: string | null }>("/members", { method: "POST", ...json(body) }),
  changeMemberRole: (userId: string, role: CompanyRole) =>
    request<Member>(`/members/${userId}`, { method: "PUT", ...json({ role }) }),
  removeMember: (userId: string) => request<void>(`/members/${userId}`, { method: "DELETE" }),
  resellers: () => request<Reseller[]>("/resellers"),
  createReseller: (name: string) => request<Reseller>("/resellers", { method: "POST", ...json({ name, is_active: true }) }),
  updateReseller: (id: string, name: string, is_active: boolean) =>
    request<Reseller>(`/resellers/${id}`, { method: "PUT", ...json({ name, is_active }) }),
  addResellerAdmin: (id: string, email: string, name: string | null) =>
    request<{ admin: ResellerAdmin; temporary_password: string | null }>(`/resellers/${id}/admins`,
      { method: "POST", ...json({ email, name }) }),
  removeResellerAdmin: (id: string, userId: string) =>
    request<void>(`/resellers/${id}/admins/${userId}`, { method: "DELETE" }),

  // ---------- bill import ----------
  billCapabilities: () => request<BillCapabilities>("/documents/capabilities"),
  extractBill: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<BillExtract>("/documents/extract", { method: "POST", body: form });
  },

  // ---------- banking ----------
  shutdown: () => request<void>("/system/shutdown", { method: "POST" }),
  company: () => request<Company>("/company"),
  branding: () => request<Branding>("/company/branding"),
  uploadLogo: (file: File) => {
    const form = new FormData();
    form.append("file", file);
    return request<Company>("/company/logo", { method: "PUT", body: form });
  },
  removeLogo: () => request<Company>("/company/logo", { method: "DELETE" }),
  updateCompany: (body: Pick<Company, "name" | "legal_name" | "fiscal_year_start_month">) =>
    request<Company>("/company", { method: "PUT", ...json(body) }),

  accounts: (includeInactive = false) =>
    request<Account[]>(`/accounts${query({ include_inactive: includeInactive ? "true" : undefined })}`),
  createAccount: (body: AccountInput) => request<Account>("/accounts", { method: "POST", ...json(body) }),
  updateAccount: (id: string, body: AccountInput) => request<Account>(`/accounts/${id}`, { method: "PUT", ...json(body) }),
  forgetCsvProfile: (id: string) => request<void>(`/accounts/${id}/csv-profile`, { method: "DELETE" }),

  customers: (includeInactive = false) =>
    request<Customer[]>(`/customers${query({ include_inactive: includeInactive ? "true" : undefined })}`),
  createCustomer: (body: Omit<Customer, "id">) => request<Customer>("/customers", { method: "POST", ...json(body) }),
  updateCustomer: (id: string, body: Omit<Customer, "id">) =>
    request<Customer>(`/customers/${id}`, { method: "PUT", ...json(body) }),

  previewImport: (accountId: string, file: File, mapping?: CsvMapping | null) => {
    const form = new FormData();
    form.append("account_id", accountId);
    if (mapping) form.append("mapping", JSON.stringify(mapping));
    form.append("file", file);
    return request<ImportPreview>("/imports/preview", { method: "POST", body: form });
  },
  commitImport: (accountId: string, file: File, mapping?: CsvMapping | null) => {
    const form = new FormData();
    form.append("account_id", accountId);
    if (mapping) form.append("mapping", JSON.stringify(mapping));
    form.append("file", file);
    return request<ImportBatch>("/imports", { method: "POST", body: form });
  },
  imports: (accountId?: string) => request<ImportBatch[]>(`/imports${query({ account_id: accountId })}`),
  undoImport: (id: string) => request<ImportBatch>(`/imports/${id}/undo`, { method: "POST" }),

  transactions: (f: TxnFilters, page = 1, pageSize = 50) =>
    request<TxnPage>(`/transactions${query({ ...f, page, page_size: pageSize })}`),
  createTransaction: (body: ManualTxnInput) => request<Txn>("/transactions", { method: "POST", ...json(body) }),
  updateTransaction: (id: string, body: TxnUpdate) =>
    request<Txn>(`/transactions/${id}`, { method: "PATCH", ...json(body) }),
  approveTransaction: (id: string) => request<Txn>(`/transactions/${id}/approve`, { method: "POST" }),
  bulkApprove: (ids: string[]) => request<BulkResult>("/transactions/bulk-approve", { method: "POST", ...json({ ids }) }),
  approveConfident: (min_confidence: number, account_id?: string) =>
    request<BulkResult>("/transactions/approve-confident", { method: "POST", ...json({ min_confidence, account_id: account_id || null }) }),
  excludeTransaction: (id: string) => request<Txn>(`/transactions/${id}/exclude`, { method: "POST" }),
  restoreTransaction: (id: string) => request<Txn>(`/transactions/${id}/restore`, { method: "POST" }),
  notDuplicate: (id: string) => request<Txn>(`/transactions/${id}/not-duplicate`, { method: "POST" }),
  candidates: (id: string) => request<Candidates>(`/transactions/${id}/candidates`),
  linkTransfer: (id: string, peer_id: string) =>
    request<Txn>(`/transactions/${id}/link-transfer`, { method: "POST", ...json({ peer_id }) }),
  unlinkTransfer: (id: string) => request<Txn>(`/transactions/${id}/unlink-transfer`, { method: "POST" }),
  createExpenseFromTxn: (id: string) => request<ExpenseDetail>(`/transactions/${id}/create-expense`, { method: "POST" }),
};
