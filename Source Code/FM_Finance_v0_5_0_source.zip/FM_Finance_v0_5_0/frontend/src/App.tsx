import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import Layout from "./components/Layout";
import { useAuth } from "./context";
import AccountsPage from "./pages/AccountsPage";
import BankingPage from "./pages/BankingPage";
import DashboardPage from "./pages/DashboardPage";
import ExpenseFormPage from "./pages/ExpenseFormPage";
import ExpensesPage from "./pages/ExpensesPage";
import CompaniesPage from "./pages/CompaniesPage";
import ImportPage from "./pages/ImportPage";
import NoCompanyPage from "./pages/NoCompanyPage";
import ResellersPage from "./pages/ResellersPage";
import TeamPage from "./pages/TeamPage";
import LoginPage from "./pages/LoginPage";
import SettingsPage from "./pages/SettingsPage";

export default function App() {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div className="boot">Loading…</div>;

  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="*" element={<Navigate to="/login" replace state={{ from: location.pathname + location.search }} />} />
      </Routes>
    );
  }

  if (user.role === "none") {
    return (
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<NoCompanyPage />} />
          <Route path="companies" element={<CompaniesPage />} />
          {user.is_platform_admin && <Route path="resellers" element={<ResellersPage />} />}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={<Navigate to="/" replace />} />
      <Route element={<Layout />}>
        <Route index element={<DashboardPage />} />
        <Route path="expenses" element={<ExpensesPage />} />
        <Route path="expenses/new" element={<ExpenseFormPage />} />
        <Route path="expenses/:id" element={<ExpenseFormPage />} />
        <Route path="banking" element={<BankingPage />} />
        <Route path="banking/import" element={<ImportPage />} />
        <Route path="accounts" element={<AccountsPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="companies" element={<CompaniesPage />} />
        {user.role === "admin" && <Route path="team" element={<TeamPage />} />}
        {user.is_platform_admin && <Route path="resellers" element={<ResellersPage />} />}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
