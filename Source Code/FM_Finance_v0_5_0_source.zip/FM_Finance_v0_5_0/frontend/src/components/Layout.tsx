import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { api } from "../api";
import BrandMark from "./BrandMark";
import CompanySwitcher from "./CompanySwitcher";
import { useAuth, useToast } from "../context";
import type { User } from "../types";

interface NavItem { to: string; label: string; end: boolean; show: (u: User) => boolean }

const inCompany = (u: User) => u.role !== "none";
const canBank = (u: User) => u.role === "admin" || u.role === "approver" || u.role === "viewer";
const NAV: NavItem[] = [
  { to: "/", label: "Dashboard", end: true, show: inCompany },
  { to: "/banking", label: "Banking", end: false, show: canBank },
  { to: "/expenses", label: "Expenses", end: true, show: inCompany },
  { to: "/expenses/new", label: "Add expense", end: true, show: (u) => inCompany(u) && u.role !== "viewer" },
  { to: "/accounts", label: "Accounts", end: true, show: canBank },
  { to: "/team", label: "Team", end: true, show: (u) => u.role === "admin" },
  { to: "/settings", label: "Settings", end: true, show: inCompany },
];
const ADMIN_NAV: NavItem[] = [
  { to: "/companies", label: "Companies", end: true,
    show: (u) => u.company_count > 1 || u.is_platform_admin || u.is_reseller_admin },
  { to: "/resellers", label: "Resellers", end: true, show: (u) => u.is_platform_admin },
];

export default function Layout() {
  const { user, settings, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [stopped, setStopped] = useState(false);

  async function signOut() {
    await logout();
    navigate("/login", { replace: true });
  }

  async function exitApp() {
    if (!window.confirm("Stop F&M Finance? You'll need to start FMFinance.exe again to use it.")) return;
    try {
      await api.shutdown();
      setStopped(true);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not stop the app");
    }
  }

  if (stopped) {
    return (
      <div className="login">
        <div className="login-card">
          <h1>F&amp;M Finance has stopped</h1>
          <p className="muted">Your data is saved. You can close this tab. Start FMFinance.exe to open it again.</p>
        </div>
      </div>
    );
  }
  if (!user) return null;
  const adminLinks = ADMIN_NAV.filter((n) => n.show(user));

  return (
    <div className="shell">
      <aside className="sidebar">
        <BrandMark />
        <CompanySwitcher />
        <nav aria-label="Main">
          {NAV.filter((n) => n.show(user)).map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
              {n.label}
            </NavLink>
          ))}
          {adminLinks.length > 0 && <div className="nav-section">Administration</div>}
          {adminLinks.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
              {n.label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div className="who">{user.name}</div>
          <button type="button" className="link-button" onClick={() => void signOut()}>Sign out</button>
          {settings?.desktop_mode && user.role === "admin" && (
            <button type="button" className="link-button danger" onClick={() => void exitApp()}>Exit app</button>
          )}
          {settings && <div className="version">v{settings.version}{settings.database === "sqlite" ? " (test database)" : ""}</div>}
        </div>
      </aside>
      <main className="main">
        {user.role === "viewer" && (
          <div className="viewonly-banner" role="status">You have view-only access to {user.company_name}.</div>
        )}
        <Outlet />
      </main>
    </div>
  );
}
