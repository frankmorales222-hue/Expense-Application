# F&M Finance v0.5.0: build handoff for ChatGPT

I'm attaching FM_Finance_v0_5_0_source.zip. The source has been reviewed and tested.
Your job is packaging and build verification only: do NOT change application code (backend/app,
frontend/src, backend/alembic, backend/tests). If something fails, show me the exact error and
propose the smallest packaging-only fix before applying it.

## Build (same process as v0.4.1)
1. 64-bit Python 3.12 and Node 20+.
2. Frontend: `npm ci` then `npm run build` in frontend\.
3. Install backend\requirements-portable.txt exactly as pinned, plus pyinstaller==6.22.3, pytest==8.3.4,
   httpx==0.28.1. No --upgrade.
4. Tests: in backend\, set TEST_DATABASE_URL=sqlite:///data/fm_finance_test.db and run pytest -q.
   Expected: 88 passed, 1 skipped.
5. Build with packaging\fm_finance_portable.spec (collect_submodules("app") bundles every app module,
   including app.schema_multicompany, app.tenancy and app.access, which this version adds).
6. `FMFinance.exe --selftest` must write selftest.txt starting with PASS.
7. Start the EXE from an empty folder with a prepared .env and check /api/health: version 0.5.0,
   database ok, storage ok.
Version is 0.5.0 everywhere. Do not change it.

## Upgrade check (important for this version)
The 0010/0011 migrations move existing data into a company. Please also verify an upgrade:
1. Copy my v0.4.1 data folder (with real expenses) to a scratch folder, never my original.
2. Start the v0.5.0 EXE there. It must start, and the expenses, receipts, logo and bank data must all
   still be visible after signing in. Report any error from the logs folder.

## Smoke test I will run on Windows (for reference when diagnosing)
- Sign in: my company opens with all my existing data; the sidebar shows the company switcher.
- Companies: add a second company; switch to it; it's empty with its own default categories.
  Switch back; my data is unchanged.
- Team: add a person as Bookkeeper and one as View only; sign in as each in a private window and
  check what they can do.
- Resellers: add a reseller and an administrator; sign in as that administrator and add a client
  company; I (platform admin) can't open that client's books.
- Bill import, banking, logo and Exit app still work.

Deliver: portable-output\FMFinance.exe, the build log, the test summary, and the upgrade-check result.
