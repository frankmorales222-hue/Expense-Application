import { Fragment, useCallback, useEffect, useState, type FormEvent } from "react";
import TempPassword from "../components/TempPassword";
import { useAuth, useToast } from "../context";
import { api } from "../api";
import { ROLE_HELP, ROLE_LABEL } from "../format";
import type { CompanyRole, Member } from "../types";

const ROLES: CompanyRole[] = ["owner", "accountant", "bookkeeper", "employee", "viewer"];

export default function TeamPage() {
  const { user } = useAuth();
  const toast = useToast();
  const [members, setMembers] = useState<Member[]>([]);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<CompanyRole>("bookkeeper");
  const [busy, setBusy] = useState(false);
  const [created, setCreated] = useState<{ email: string; password: string } | null>(null);

  const load = useCallback(() => {
    api.members().then(setMembers).catch((e: Error) => toast.error(e.message));
  }, [toast]);
  useEffect(load, [load]);

  async function add(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const r = await api.addMember({ email: email.trim(), name: name.trim() || null, role });
      if (r.temporary_password) setCreated({ email: r.member.email, password: r.temporary_password });
      else toast.success(`${r.member.name} can now open ${user?.company_name}`);
      setEmail(""); setName("");
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not add the person");
    } finally {
      setBusy(false);
    }
  }

  async function changeRole(m: Member, next: CompanyRole) {
    try {
      await api.changeMemberRole(m.user_id, next);
      toast.success(`${m.name} is now ${(ROLE_LABEL[next] ?? next).toLowerCase()}`);
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not change the role");
    }
  }

  async function remove(m: Member) {
    if (!window.confirm(`Remove ${m.name}'s access to ${user?.company_name}? Their past entries stay.`)) return;
    try {
      await api.removeMember(m.user_id);
      toast.success(`${m.name} no longer has access`);
      load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not remove the person");
    }
  }

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Team</h1>
          <p className="muted">Who can open {user?.company_name}, and what they can do there.</p>
        </div>
      </header>

      {created && <TempPassword email={created.email} password={created.password} onDone={() => setCreated(null)} />}

      <section className="panel flush">
        <div className="table-wrap">
          <table className="ledger settings-table">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th /></tr></thead>
            <tbody>
              {members.map((m) => (
                <tr key={m.user_id}>
                  <td>{m.name}{m.is_you && <span className="tag">You</span>}</td>
                  <td>{m.email}</td>
                  <td>
                    {m.via_reseller ? <span>Owner <span className="muted">(reseller administrator)</span></span> : (
                      <select className="cell-input" value={m.role} aria-label={`Role for ${m.name}`}
                        onChange={(e) => void changeRole(m, e.target.value as CompanyRole)}>
                        {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                      </select>
                    )}
                  </td>
                  <td className="row-actions">
                    {!m.via_reseller && !m.is_you && (
                      <button type="button" className="btn btn-small btn-danger-quiet" onClick={() => void remove(m)}>Remove</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="panel">
        <h2>Give someone access</h2>
        <form className="inline-form flat" onSubmit={add}>
          <label className="field grow"><span>Email</span>
            <input type="email" value={email} maxLength={255} required onChange={(e) => setEmail(e.target.value)} /></label>
          <label className="field grow"><span>Name (for new sign-ins)</span>
            <input value={name} maxLength={255} onChange={(e) => setName(e.target.value)} /></label>
          <label className="field"><span>Role</span>
            <select value={role} onChange={(e) => setRole(e.target.value as CompanyRole)}>
              {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
            </select></label>
          <button type="submit" className="btn btn-primary" disabled={busy || !email.trim()}>{busy ? "Adding…" : "Add"}</button>
        </form>
        <dl className="facts role-help">
          {ROLES.map((r) => <Fragment key={r}><dt>{ROLE_LABEL[r]}</dt><dd>{ROLE_HELP[r]}</dd></Fragment>)}
        </dl>
        <p className="hint">Someone who already signs in to F&amp;M Finance (for another company) keeps their password.
          New people get a temporary password shown once here.</p>
      </section>
    </div>
  );
}
