# F&M Finance v0.7.0: build handoff for ChatGPT

I'm attaching FM_Finance_v0_7_0_source.zip. The source has been reviewed and tested.
Your job is packaging and build verification only: do NOT change application code (backend/app,
frontend/src, backend/alembic, backend/tests). If something fails, show me the exact error and
propose the smallest packaging-only fix before applying it.

## Build (same process as v0.6.0)
1. 64-bit Python 3.12 and Node 20+.
2. Frontend: `npm ci` then `npm run build` in frontend\.
3. Install backend\requirements-portable.txt exactly as pinned, plus pyinstaller==6.22.3, pytest==8.3.4,
   httpx==0.28.1. No --upgrade.
   NEW in this version: fpdf2==2.8.9 (invoice PDFs), fonttools==4.66.1 and defusedxml==0.7.1 (needed by
   fpdf2), and cryptography==50.0.2 (encrypts the saved email password). All have Windows wheels.
4. Tests: in backend\, set TEST_DATABASE_URL=sqlite:///data/fm_finance_test.db and run pytest -q.
   Expected: 125 passed, 1 skipped.
5. Build with packaging\fm_finance_portable.spec. The spec now also bundles fpdf and fontTools
   (collect_all) and lists the new modules as hidden imports: app.schema_sales, the app.invoicing
   package (pdf, mailer, secretbox, service), app.routers.invoices, payments, items, sales and mail,
   and cryptography.fernet.
6. `FMFinance.exe --selftest` must write selftest.txt starting with PASS. It now also contains
   `invoice_pdf: ok` and `mail_password_encryption: ok`; if either says ERROR, fpdf2 or cryptography
   wasn't bundled (packaging fix only).
7. Start the EXE from an empty folder with a prepared .env and check /api/health: version 0.7.0,
   database ok, storage ok.
Version is 0.7.0 everywhere. Do not change it.

## Upgrade check (this version adds tables)
Copy my v0.6.0 data folder next to the new EXE (a COPY, not the original), start it, sign in and check:
- The log shows no errors and the database is at revision 0014_sqlite_sales.
- Settings > Books still says "Your books are in balance."
- Chart of accounts now includes "Billable Expense Income".
- Expenses, bills and banking look exactly as before.
- Create a test invoice, open Preview PDF (it shows my logo), then delete the invoice.

## What changed in v0.7.0
Invoices with PDF (logo, company details, payment instructions) and email from the company's own
mailbox (Microsoft 365, Gmail or any SMTP server; password stored encrypted); products and services;
billable expenses added to invoices; receive payment across several invoices, matched to the bank
deposit; customers page with balances and payment history; A/R aging and sales by customer reports;
dashboard money-in panel; grouped navigation. Database migration 0014 (SQLite) / 0015 (PostgreSQL).

## Smoke test I will run on Windows (for reference when diagnosing)
- Settings > Company: fill in address, phone and payment instructions. Settings > Email: Microsoft 365
  preset, my mailbox and password, Save, Send test (arrives in my inbox).
- Products and services: add "Managed IT – per user" at $85.
- Create an invoice for a customer, Save and send: the email arrives with Invoice-1001.pdf attached.
- Receive payment for it, matched to an imported deposit: the invoice shows Paid and the deposit is
  approved in Banking; the Balance sheet still balances.
- Reports > A/R aging and Sales by customer show the right amounts.
- Companies, team roles, bills, bill import, logo and Exit app still work.

Deliver: portable-output\FMFinance.exe, the build log, the test summary, selftest.txt and the upgrade
check result.
