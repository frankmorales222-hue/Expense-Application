"""People with access to the current company, and their roles (owners only)."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import audit
from ..access import find_or_create_user
from ..database import get_db
from ..models import CompanyMember, ResellerAdmin, User
from ..schemas import MemberAdded, MemberIn, MemberOut, MemberRoleIn
from ..security import require_roles
from .util import current_company

router = APIRouter(prefix="/api/members", tags=["members"])
OWNERS = require_roles("admin", viewer_can_read=False)  # member emails are for owners only


def _out(m: CompanyMember, u: User, me: User) -> MemberOut:
    return MemberOut(user_id=u.id, name=u.name, email=u.email, role=m.role, via_reseller=False,
                     is_you=u.id == me.id, is_active=u.is_active)


@router.get("", response_model=list[MemberOut])
def list_members(db: Session = Depends(get_db), me: User = Depends(OWNERS)) -> list[MemberOut]:
    company = current_company(db)
    out = [_out(m, u, me) for m, u in db.execute(
        select(CompanyMember, User).join(User, User.id == CompanyMember.user_id)
        .where(CompanyMember.company_id == company.id).order_by(User.name)).all()]
    if company.reseller_id:
        listed = {m.user_id for m in out}
        for u in db.scalars(select(User).join(ResellerAdmin, ResellerAdmin.user_id == User.id)
                            .where(ResellerAdmin.reseller_id == company.reseller_id).order_by(User.name)):
            if u.id not in listed:
                out.append(MemberOut(user_id=u.id, name=u.name, email=u.email, role="owner", via_reseller=True,
                                     is_you=u.id == me.id, is_active=u.is_active))
    return out


def _owner_count(db: Session, company_id: uuid.UUID) -> int:
    return db.scalar(select(func.count()).select_from(CompanyMember).where(
        CompanyMember.company_id == company_id, CompanyMember.role == "owner")) or 0


@router.post("", response_model=MemberAdded, status_code=status.HTTP_201_CREATED)
def add_member(payload: MemberIn, db: Session = Depends(get_db), me: User = Depends(OWNERS)) -> MemberAdded:
    company = current_company(db)
    user, password = find_or_create_user(db, payload.email, payload.name)
    if db.get(CompanyMember, (company.id, user.id)):
        raise HTTPException(status.HTTP_409_CONFLICT, f"{user.email} already has access to {company.name}")
    member = CompanyMember(company_id=company.id, user_id=user.id, role=payload.role)
    db.add(member)
    audit.record(db, entity_type="company", entity_id=company.id, action="member_added", user_id=me.id,
                 changes={"email": user.email, "role": payload.role, "new_user": password is not None})
    db.commit()
    return MemberAdded(member=_out(member, user, me), temporary_password=password)


def _load(db: Session, user_id: uuid.UUID) -> tuple[CompanyMember, User]:
    company = current_company(db)
    member = db.get(CompanyMember, (company.id, user_id))
    if member is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Member not found")
    return member, db.get(User, user_id)


@router.put("/{user_id}", response_model=MemberOut)
def change_role(user_id: uuid.UUID, payload: MemberRoleIn, db: Session = Depends(get_db),
                me: User = Depends(OWNERS)) -> MemberOut:
    member, user = _load(db, user_id)
    if member.role == "owner" and payload.role != "owner" and _owner_count(db, member.company_id) <= 1:
        raise HTTPException(status.HTTP_409_CONFLICT, "A company needs at least one owner")
    if member.role != payload.role:
        audit.record(db, entity_type="company", entity_id=member.company_id, action="member_role_changed",
                     user_id=me.id, changes={"email": user.email, "role": [member.role, payload.role]})
        member.role = payload.role
        db.commit()
    return _out(member, user, me)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_member(user_id: uuid.UUID, db: Session = Depends(get_db), me: User = Depends(OWNERS)) -> Response:
    member, user = _load(db, user_id)
    if member.role == "owner" and _owner_count(db, member.company_id) <= 1:
        raise HTTPException(status.HTTP_409_CONFLICT, "A company needs at least one owner")
    audit.record(db, entity_type="company", entity_id=member.company_id, action="member_removed", user_id=me.id,
                 changes={"email": user.email, "role": member.role})
    db.delete(member)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
