"""Outgoing email settings (SMTP) for sending invoices."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import audit
from ..database import get_db
from ..invoicing import mailer
from ..invoicing.secretbox import SecretUnavailable, encrypt
from ..models import EmailSettings, User
from ..schemas import EmailSettingsIn, EmailSettingsOut, TestEmailIn
from ..security import require_roles
from .util import current_company

router = APIRouter(prefix="/api/email-settings", tags=["email"])


def _out(row: EmailSettings | None) -> EmailSettingsOut:
    if row is None:
        return EmailSettingsOut(configured=False)
    return EmailSettingsOut(configured=True, smtp_host=row.smtp_host, smtp_port=row.smtp_port, security=row.security,
                            username=row.username, has_password=bool(row.password_encrypted),
                            from_email=row.from_email, from_name=row.from_name, reply_to=row.reply_to,
                            copy_me=row.copy_me)


@router.get("", response_model=EmailSettingsOut)
def get_settings_(db: Session = Depends(get_db), _: User = Depends(require_roles("admin", "approver"))) -> EmailSettingsOut:
    return _out(db.scalar(select(EmailSettings)))


@router.put("", response_model=EmailSettingsOut)
def save_settings(payload: EmailSettingsIn, db: Session = Depends(get_db),
                  user: User = Depends(require_roles("admin"))) -> EmailSettingsOut:
    company = current_company(db)
    row = db.scalar(select(EmailSettings))
    if row is None:
        row = EmailSettings(company_id=company.id)
        db.add(row)
    for field in ("smtp_host", "smtp_port", "security", "username", "from_email", "from_name", "reply_to", "copy_me"):
        setattr(row, field, getattr(payload, field))
    if payload.password is not None:
        try:
            row.password_encrypted = encrypt(payload.password) if payload.password else None
        except SecretUnavailable as exc:
            raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    audit.record(db, entity_type="company", entity_id=company.id, action="email_settings_saved", user_id=user.id,
                 changes={"host": payload.smtp_host, "port": payload.smtp_port, "from": payload.from_email,
                          "password_changed": payload.password is not None})
    db.commit()
    return _out(row)


@router.delete("", status_code=status.HTTP_204_NO_CONTENT)
def remove_settings(db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))) -> Response:
    row = db.scalar(select(EmailSettings))
    if row is not None:
        db.delete(row)
        audit.record(db, entity_type="company", entity_id=current_company(db).id, action="email_settings_removed",
                     user_id=user.id)
        db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/test")
def send_test(payload: TestEmailIn, db: Session = Depends(get_db),
              _: User = Depends(require_roles("admin"))) -> dict:
    from .invoices import smtp_config

    try:
        cfg = smtp_config(db)
    except SecretUnavailable as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, str(exc)) from exc
    if cfg is None:
        raise HTTPException(status.HTTP_409_CONFLICT, "Save the email settings first")
    company = current_company(db)
    msg = mailer.build_message(
        cfg, [payload.to], f"Test email from F&M Finance ({company.name})",
        f"This is a test from F&M Finance.\n\nIf you're reading it, {company.name} can email invoices from "
        f"{cfg.from_email}.")
    try:
        mailer.send(cfg, msg)
    except mailer.MailError as exc:
        raise HTTPException(status.HTTP_502_BAD_GATEWAY, str(exc)) from exc
    return {"sent": True, "to": payload.to}
