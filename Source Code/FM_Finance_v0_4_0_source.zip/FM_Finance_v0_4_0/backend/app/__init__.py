"""F&M Finance — expense tracking and banking backend."""

__version__ = "0.4.0"
