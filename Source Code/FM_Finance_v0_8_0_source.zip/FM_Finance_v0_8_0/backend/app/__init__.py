"""F&M Finance — multi-company accounting backend."""

__version__ = "0.8.0"
