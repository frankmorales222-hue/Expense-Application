import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "../api";
import { useAuth, useToast } from "../context";
import { formatDate } from "../format";
import type { CompanyPlan, ModuleKey, PlanKey, PlansCatalog } from "../types";

interface Draft { plan: PlanKey | "custom"; modules: ModuleKey[]; user_limit: string }

const toDraft = (c: CompanyPlan): Draft => ({
  plan: (c.plan as PlanKey | "custom" | null) ?? "custom", modules: c.modules, user_limit: c.user_limit ? String(c.user_limit) : "",
});

export default function PlansPage() {
  const { user } = useAuth();
  const toast = useToast();
  const [catalog, setCatalog] = useState<PlansCatalog | null>(null);
  const [rows, setRows] = useState<CompanyPlan[] | null>(null);
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [search, setSearch] = useState("");

  const load = useCallback(() => {
    api.companyPlans().then((r) => { setRows(r); setDrafts(Object.fromEntries(r.map((c) => [c.id, toDraft(c)]))); })
      .catch((e: Error) => toast.error(e.message));
  }, [toast]);
  useEffect(() => { api.plansCatalog().then(setCatalog).catch(() => undefined); load(); }, [load]);

  const planDefaults = useMemo(() => Object.fromEntries((catalog?.plans ?? []).map((p) => [p.key, p])), [catalog]);

  function choosePlan(id: string, plan: PlanKey | "custom") {
    setDrafts((d) => {
      const cur = d[id];
      if (!cur) return d;
      const p = planDefaults[plan];
      return { ...d, [id]: p ? { plan, modules: [...p.modules], user_limit: p.user_limit ? String(p.user_limit) : "" } : { ...cur, plan } };
    });
  }

  function toggle(id: string, key: ModuleKey) {
    setDrafts((d) => {
      const cur = d[id];
      if (!cur) return d;
      const modules = cur.modules.includes(key) ? cur.modules.filter((m) => m !== key) : [...cur.modules, key];
      return { ...d, [id]: { ...cur, modules, plan: "custom" } };
    });
  }

  async function save(c: CompanyPlan) {
    const d = drafts[c.id];
    if (!d) return;
    const limit = d.user_limit.trim() ? Number(d.user_limit) : null;
    if (limit !== null && !(limit >= 1)) { toast.error("The user limit must be 1 or more (or empty for unlimited)"); return; }
    setBusy(c.id);
    try {
      const out = await api.setCompanyPlan(c.id, { plan: d.plan, modules: d.modules, user_limit: limit });
      setRows((r) => (r ?? []).map((x) => (x.id === c.id ? out : x)));
      setDrafts((all) => ({ ...all, [c.id]: toDraft(out) }));
      toast.success(`${c.name}: ${out.plan_label}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save the plan");
    } finally {
      setBusy(null);
    }
  }

  const q = search.trim().toLowerCase();
  const list = (rows ?? []).filter((c) => !q || c.name.toLowerCase().includes(q) || (c.reseller_name ?? "").toLowerCase().includes(q));
  const modules = catalog?.modules ?? [];

  return (
    <div className="page">
      <header className="page-head">
        <div>
          <h1>Plans and modules</h1>
          <p className="muted">
            {user?.is_platform_admin ? "Every company in F&M Finance. " : "Your clients. "}
            Tick the modules each client pays for. Core (dashboard, expenses, banking, chart of accounts, profit and loss,
            balance sheet, closing date, history, export, settings) is in every plan. Turning a module off keeps its records
            readable; nothing is deleted. Only names and plans are shown here, never a company's books.
          </p>
        </div>
      </header>

      {catalog && (
        <section className="panel plan-legend">
          {catalog.plans.map((p) => (
            <div key={p.key}>
              <strong>{p.label}</strong>
              <span className="muted small"> · {p.modules.length === modules.length ? "all modules" : p.modules.map((m) => modules.find((x) => x.key === m)?.label).join(", ")}
                {" "}· {p.user_limit ? `${p.user_limit} user${p.user_limit === 1 ? "" : "s"}` : "unlimited users"}</span>
            </div>
          ))}
          <div className="muted small">The company's Accountant always has the accounting tools and doesn't count as a user.</div>
        </section>
      )}

      <div className="toolbar">
        <label className="field grow"><span className="sr-only">Search</span>
          <input type="search" placeholder="Search company or reseller" value={search} onChange={(e) => setSearch(e.target.value)} /></label>
      </div>

      <section className="panel flush">
        {rows && list.length === 0 ? <div className="empty inner"><p>No companies.</p></div> : (
          <div className="table-wrap">
            <table className="ledger plans-table">
              <thead><tr>
                <th>Company</th><th>Plan</th>
                {modules.map((m) => <th key={m.key} className="center" title={m.description}>{m.label}</th>)}
                <th className="num">Users</th><th><span className="sr-only">Save</span></th>
              </tr></thead>
              <tbody>
                {list.map((c) => {
                  const d = drafts[c.id];
                  if (!d) return null;
                  const dirty = JSON.stringify(toDraft(c)) !== JSON.stringify({ ...d, modules: modules.map((m) => m.key).filter((k) => d.modules.includes(k)) });
                  return (
                    <tr key={c.id} className={c.is_active ? "" : "inactive"}>
                      <td><strong>{c.name}</strong>
                        <div className="muted small">{c.reseller_name ? `Client of ${c.reseller_name}` : "Direct client"} · since {formatDate(c.created_at)}</div></td>
                      <td>
                        <select value={d.plan} aria-label={`${c.name} plan`} onChange={(e) => choosePlan(c.id, e.target.value as PlanKey | "custom")}>
                          {(catalog?.plans ?? []).map((p) => <option key={p.key} value={p.key}>{p.label}</option>)}
                          <option value="custom">Custom</option>
                        </select>
                        {c.plan === null && <div className="muted small">Before plans: all modules</div>}
                      </td>
                      {modules.map((m) => (
                        <td key={m.key} className="center">
                          <input type="checkbox" checked={d.modules.includes(m.key)} aria-label={`${c.name}: ${m.label}`}
                            onChange={() => toggle(c.id, m.key)} />
                        </td>
                      ))}
                      <td className="num">
                        <div className="seat-cell">
                          <span className={c.user_limit !== null && c.seats_used >= c.user_limit ? "overdue-text" : "muted"}>{c.seats_used} of</span>
                          <input inputMode="numeric" className="num-input seat-input" value={d.user_limit} placeholder="∞" aria-label={`${c.name} user limit`}
                            onChange={(e) => setDrafts((all) => ({ ...all, [c.id]: { ...d, plan: "custom", user_limit: e.target.value.replace(/[^0-9]/g, "") } }))} />
                        </div>
                      </td>
                      <td className="row-actions">
                        <button type="button" className={dirty ? "btn btn-primary" : "btn"} disabled={!dirty || busy !== null}
                          onClick={() => void save(c)}>{busy === c.id ? "Saving…" : "Save"}</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
