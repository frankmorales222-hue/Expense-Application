# F&M Finance v0.3.0: packaging handoff for ChatGPT

I'm attaching FM_Finance_v0_3_0_source.zip. The source has been reviewed and tested.
Your job is packaging only: do NOT change application code (backend/app, frontend/src,
backend/alembic, backend/tests). If something fails, show me the exact error and propose the
smallest packaging-only fix before applying it.

Goal: a single-file portable Windows EXE, portable-output\FMFinance.exe, SQLite only.

## Build requirements
1. Use 64-bit Python 3.12 for the build (most predictable wheels) and Node.js 20 LTS or newer.
2. Install exactly backend\requirements-portable.txt plus pyinstaller==6.22.3. Do not add --upgrade
   and do not change pinned versions. If a pinned wheel truly won't install on Python 3.12, tell me
   which one and why before changing anything.
3. Build the frontend with `npm ci` then `npm run build` in frontend\ (a prebuilt dist is included,
   but rebuild it).
4. Before packaging, run the tests and show me the summary line:
       cd backend
       set TEST_DATABASE_URL=sqlite:///data/fm_finance_test.db
       ..\.venv\Scripts\python.exe -m pip install pytest==8.3.4 httpx==0.28.1
       ..\.venv\Scripts\python.exe -m pytest -q
   Expected: all pass, 1 skipped (the PostgreSQL transfer test).
5. Run packaging\build_portable.bat (spec: packaging\fm_finance_portable.spec, windowed,
   console=False). Confirm the bundle contains backend\alembic\versions including
   0004_sqlite_phase1.py and 0005_postgresql_phase1.py, and that app.schema_phase1 and the
   app.banking package are included (they are listed in hiddenimports).
6. Version is 0.3.0 everywhere. Do not change it.

## Smoke test on Windows (report each result)
- First launch from an empty folder shows the first-run message box with a temporary password,
  creates .env, data\fm_finance.db and INITIAL_LOGIN.txt, and opens the browser.
- Sign in, change the password in Settings: INITIAL_LOGIN.txt is deleted and
  ADMIN_INITIAL_PASSWORD= in .env is now empty.
- Accounts: add a checking account and a credit card.
- Banking > Import statement: import a CSV, then import the same file again.
  The second import adds 0 and skips every row.
- Approve a transaction. Use "Add receipt" on a money-out row, upload a PDF on the expense page;
  the file is saved under data\receipts.
- Launch FMFinance.exe a second time while it's running: it only opens the browser.
- Sidebar "Exit app": the FMFinance.exe process ends.
- Error handling: occupy port 8010 with another program (or set APP_PORT to a used port),
  then start the EXE: a message box explains the problem instead of nothing happening.

## Upgrading an existing v0.2.x test install
Copy the new FMFinance.exe over the old one, keeping .env and data\. Add these lines to .env:
    DESKTOP_MODE=true
    RECEIPT_STORAGE=local
    RECEIPT_DIR=data/receipts
Migrations run on start. Back up data\ first.

Deliver: portable-output\FMFinance.exe plus the full build log and the test summary.

## Windows build via GitHub Actions (when your environment can't build Windows EXEs)
The repo includes .github/workflows/build-windows.yml. On GitHub's Windows runner it: checks for
64-bit Python 3.12, builds the frontend, installs the pinned packages, runs the tests, builds
FMFinance.exe with packaging\fm_finance_portable.spec, starts the EXE with a prepared .env and
checks /api/health (version 0.3.0, database ok), then uploads FMFinance.exe as the artifact
"FMFinance-v0.3.0". If a run fails, read the failing step's log and propose a packaging-only fix.
