from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import audit
from ..database import get_db
from ..models import Company, User
from ..schemas import CompanyIn, CompanyOut
from ..security import current_user, require_roles
from .util import current_company

router = APIRouter(prefix="/api/company", tags=["company"])


@router.get("", response_model=CompanyOut)
def get_company(db: Session = Depends(get_db), _: User = Depends(current_user)) -> Company:
    return current_company(db)


@router.put("", response_model=CompanyOut)
def update_company(payload: CompanyIn, db: Session = Depends(get_db),
                   user: User = Depends(require_roles("admin"))) -> Company:
    company = current_company(db)
    changes = {}
    for field in ("name", "legal_name", "fiscal_year_start_month"):
        new = getattr(payload, field)
        if getattr(company, field) != new:
            changes[field] = [getattr(company, field), new]
            setattr(company, field, new)
    if changes:
        audit.record(db, entity_type="company", entity_id=company.id, action="updated", user_id=user.id,
                     changes=changes)
        db.commit()
    return company
