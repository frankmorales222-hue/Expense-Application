import type { ExpenseStatus, PaymentMethod } from "./types";

const moneyFormatters = new Map<string, Intl.NumberFormat>();

export function money(amount: number, currency = "USD"): string {
  let f = moneyFormatters.get(currency);
  if (!f) {
    f = new Intl.NumberFormat("en-US", { style: "currency", currency });
    moneyFormatters.set(currency, f);
  }
  return f.format(amount);
}

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** Format a YYYY-MM-DD string without going through Date (avoids time-zone day shifts). */
export function formatDate(iso: string): string {
  const [y, m, d] = iso.slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return iso;
  return `${MONTHS[m - 1]} ${d}, ${y}`;
}

export function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" });
}

/** Local calendar date as YYYY-MM-DD. */
export function toISODate(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export const today = (): string => toISODate(new Date());

export const STATUS_LABEL: Record<ExpenseStatus, string> = {
  pending: "Pending approval",
  approved: "Approved",
  paid: "Paid",
  rejected: "Rejected",
};

export const STATUS_ACTION: Record<ExpenseStatus, string> = {
  pending: "Resubmit for approval",
  approved: "Approve",
  paid: "Mark as paid",
  rejected: "Reject",
};

export const PAYMENT_LABEL: Record<PaymentMethod, string> = {
  business_card: "Business card",
  business_bank: "Business bank account",
  personal_card: "Personal card",
  cash: "Cash",
  other: "Other",
};

export function fileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export interface DateRange {
  key: string;
  label: string;
  from?: string;
  to?: string;
}

export function presetRanges(now = new Date()): DateRange[] {
  const y = now.getFullYear();
  const m = now.getMonth();
  const q = Math.floor(m / 3) * 3;
  return [
    { key: "month", label: "This month", from: toISODate(new Date(y, m, 1)), to: toISODate(now) },
    { key: "last_month", label: "Last month", from: toISODate(new Date(y, m - 1, 1)), to: toISODate(new Date(y, m, 0)) },
    { key: "quarter", label: "This quarter", from: toISODate(new Date(y, q, 1)), to: toISODate(now) },
    { key: "ytd", label: "Year to date", from: toISODate(new Date(y, 0, 1)), to: toISODate(now) },
    { key: "12m", label: "Last 12 months", from: toISODate(new Date(y, m - 11, 1)), to: toISODate(now) },
    { key: "all", label: "All time" },
  ];
}

export const ACCOUNT_KIND_LABEL: Record<string, string> = {
  checking: "Checking",
  savings: "Savings",
  credit_card: "Credit card",
  cash: "Cash",
  other: "Other",
};

export const CATEGORY_KIND_LABEL: Record<string, string> = {
  expense: "Expense",
  income: "Income",
  equity: "Owner / equity",
};

export function confidenceLevel(c: number): "high" | "medium" | "low" | "none" {
  if (c >= 85) return "high";
  if (c >= 60) return "medium";
  if (c > 0) return "low";
  return "none";
}

export const MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August",
  "September", "October", "November", "December"];

export const ROLE_LABEL: Record<string, string> = {
  owner: "Owner",
  accountant: "Accountant",
  bookkeeper: "Bookkeeper",
  employee: "Employee",
  viewer: "View only",
};

export const ROLE_HELP: Record<string, string> = {
  owner: "Everything, including settings, bank accounts and who has access",
  accountant: "Banking, approving and editing all expenses; no settings or team",
  bookkeeper: "Banking, approving and editing all expenses; no settings or team",
  employee: "Adds and sees only their own expenses",
  viewer: "Sees everything, changes nothing",
};

// ---------- v0.7.0 sales ----------
export const TERMS_OPTIONS: { value: "due_on_receipt" | "net_15" | "net_30" | "net_45" | "net_60"; label: string; days: number }[] = [
  { value: "due_on_receipt", label: "Due on receipt", days: 0 },
  { value: "net_15", label: "Net 15", days: 15 },
  { value: "net_30", label: "Net 30", days: 30 },
  { value: "net_45", label: "Net 45", days: 45 },
  { value: "net_60", label: "Net 60", days: 60 },
];

export function addDaysISO(iso: string, days: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  return toISODate(new Date(y ?? 1970, (m ?? 1) - 1, (d ?? 1) + days));
}

export const INVOICE_STATUS_LABEL: Record<string, string> = {
  not_sent: "Not sent", sent: "Sent", partial: "Partly paid", paid: "Paid", overdue: "Overdue", void: "Void",
};

export const PAYMENT_METHOD_IN_LABEL: Record<string, string> = {
  ach: "ACH / bank transfer", check: "Check", card: "Credit card", cash: "Cash", wire: "Wire", other: "Other",
};

/** Days past the due date (0 or less means not late yet). */
export function daysLate(due: string, on: string = today()): number {
  const a = new Date(`${due}T00:00:00`);
  const b = new Date(`${on}T00:00:00`);
  return Math.round((b.getTime() - a.getTime()) / 86400000);
}
