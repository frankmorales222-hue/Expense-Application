"""Plans and modules admin (v0.8.0): the platform owner manages every company; a reseller admin manages
the companies of their reseller. Only names and plans are shown here, never a company's books."""

from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import audit, modules
from ..access import reseller_ids_administered
from ..database import get_db
from ..models import Company, Reseller, User
from ..schemas import CompanyPlanIn, CompanyPlanOut, CompanyThemeIn, ModuleInfo, PlanInfo, PlansCatalog
from ..security import current_user
from ..tenancy import acting_as

router = APIRouter(prefix="/api/plans", tags=["plans"])


@router.get("/catalog", response_model=PlansCatalog)
def catalog(_: User = Depends(current_user)) -> PlansCatalog:
    return PlansCatalog(
        modules=[ModuleInfo(key=k, label=v[0], description=v[1]) for k, v in modules.MODULES.items()],
        plans=[PlanInfo(key=k, label=v[0], modules=list(v[1]), user_limit=v[2]) for k, v in modules.PLANS.items()])


def _managed(db: Session, user: User) -> list[Company]:
    if user.is_platform_admin:
        return list(db.scalars(select(Company).order_by(Company.name)))
    resellers = reseller_ids_administered(db, user)
    if not resellers:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Only administrators can manage plans")
    return list(db.scalars(select(Company).where(Company.reseller_id.in_(resellers)).order_by(Company.name)))


def _out(db: Session, c: Company, resellers: dict) -> CompanyPlanOut:
    return CompanyPlanOut(id=c.id, name=c.name, reseller_name=resellers.get(c.reseller_id), is_active=c.is_active,
                          plan=c.plan, plan_label=modules.plan_label(c), modules=modules.enabled_list(c),
                          user_limit=c.user_limit, seats_used=modules.seats_used(db, c.id), created_at=c.created_at,
                          default_theme=c.default_theme or "classic")


@router.get("/companies", response_model=list[CompanyPlanOut])
def companies(db: Session = Depends(get_db), user: User = Depends(current_user)) -> list[CompanyPlanOut]:
    resellers = {r.id: r.name for r in db.scalars(select(Reseller))}
    return [_out(db, c, resellers) for c in _managed(db, user)]


@router.put("/companies/{company_id}", response_model=CompanyPlanOut)
def set_plan(company_id: uuid.UUID, payload: CompanyPlanIn, db: Session = Depends(get_db),
             user: User = Depends(current_user)) -> CompanyPlanOut:
    company = next((c for c in _managed(db, user) if c.id == company_id), None)
    if company is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Company not found")
    if payload.plan == "custom":
        if payload.modules is None:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "Choose the modules for a custom plan")
        chosen, limit = payload.modules, payload.user_limit
    else:
        _, plan_modules, plan_limit = modules.PLANS[payload.plan]
        chosen = payload.modules if payload.modules is not None else list(plan_modules)
        limit = payload.user_limit if "user_limit" in payload.model_fields_set else plan_limit
    unknown = [m for m in chosen if m not in modules.MODULES]
    if unknown:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"Unknown module: {unknown[0]}")
    ordered = [m for m in modules.ALL if m in chosen]
    plan = payload.plan
    if plan != "custom":
        _, plan_modules, plan_limit = modules.PLANS[plan]
        if tuple(ordered) != tuple(plan_modules) or limit != plan_limit:
            plan = "custom"  # adjusted by hand
    before = {"plan": company.plan, "modules": modules.enabled_list(company), "user_limit": company.user_limit}
    company.plan, company.modules, company.user_limit = plan, ordered, limit
    with acting_as(db, company.id):
        audit.record(db, entity_type="company", entity_id=company.id, action="plan_changed", user_id=user.id,
                     changes={"before": before, "after": {"plan": plan, "modules": ordered, "user_limit": limit}})
    db.commit()
    resellers = {r.id: r.name for r in db.scalars(select(Reseller))}
    return _out(db, company, resellers)


@router.put("/companies/{company_id}/theme", response_model=CompanyPlanOut)
def set_default_theme(company_id: uuid.UUID, payload: CompanyThemeIn, db: Session = Depends(get_db),
                      user: User = Depends(current_user)) -> CompanyPlanOut:
    """The look a client company's people get until they choose their own (v0.9.0)."""
    company = next((c for c in _managed(db, user) if c.id == company_id), None)
    if company is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Company not found")
    before = company.default_theme or "classic"
    company.default_theme = None if payload.default_theme == "classic" else payload.default_theme
    with acting_as(db, company.id):
        audit.record(db, entity_type="company", entity_id=company.id, action="default_theme_changed", user_id=user.id,
                     changes={"before": before, "after": payload.default_theme})
    db.commit()
    resellers = {r.id: r.name for r in db.scalars(select(Reseller))}
    return _out(db, company, resellers)
