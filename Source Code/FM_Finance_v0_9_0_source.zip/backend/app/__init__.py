"""F&M Finance — multi-company accounting backend."""

__version__ = "0.9.0"
