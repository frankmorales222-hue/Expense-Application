# F&M Finance v0.9.0: build handoff for ChatGPT

I'm attaching FM_Finance_v0_9_0_source.zip. The source has been reviewed and tested.
Your job is packaging and build verification only: do NOT change application code (backend/app,
frontend/src, backend/alembic, backend/tests). If something fails, show me the exact error and
propose the smallest packaging-only fix before applying it.

## Build (same process as v0.8.0)
1. 64-bit Python 3.12 and Node 20+.
2. Frontend: `npm ci` then `npm run build` in frontend\. New in v0.9.0: five font packages
   (@fontsource/lexend, source-sans-3, ibm-plex-sans, fira-sans, fira-code, all pinned 5.1.0) are in
   package.json and package-lock.json; npm ci installs them and Vite puts the font files in
   frontend\dist\assets. No other frontend changes to the build.
3. Install backend\requirements-portable.txt exactly as pinned, plus pyinstaller==6.22.3, pytest==8.3.4,
   httpx==0.28.1. No --upgrade. No new Python packages in v0.9.0.
4. Tests: in backend\, set TEST_DATABASE_URL=sqlite:///data/fm_finance_test.db and run pytest -q.
   Expected: 143 passed, 1 skipped.
5. Build with packaging\fm_finance_portable.spec. New hidden imports (already in the spec):
   app.schema_themes and app.routers.dashboard. frontend\dist must be bundled as before (it now includes
   .woff2/.woff font files; check they're inside the EXE's frontend\dist\assets).
6. `FMFinance.exe --selftest` must write selftest.txt starting with PASS.
7. Start the EXE from an empty folder with a prepared .env and check /api/health: version 0.9.0,
   database ok, storage ok.
Version is 0.9.0 everywhere. Do not change it.

## Upgrade check
Copy my v0.8.0 data folder next to the new EXE (a COPY), start it, sign in and check:
- The log shows "Running upgrade 0018_sqlite_modules -> 0020_sqlite_themes" and no errors.
- Settings > Books still says "Your books are in balance"; invoices, bills and customers are unchanged.
- The Dashboard opens with cash, the cash forecast, Coming up and New from the bank (no error message).
- Settings > Appearance shows Classic selected; switching to Dark and Executive changes the whole app
  immediately, and the choice is still there after signing out and in.
- Administration > Plans and modules shows a "Default look" column (Classic for every company).

## What changed in v0.9.0
A new look in three themes (Classic, Executive, Dark) chosen per person, with a default per company set
by the platform owner or reseller admin; a new dashboard (key numbers, account balances, 30-day cash
forecast, coming up, income and expenses, invoice status, bank transactions to approve, this month vs last);
icons and restyled pages throughout; keyboard shortcuts in Banking for review. Migrations 0020 (SQLite) /
0021 (PostgreSQL).

## Smoke test I will run on Windows (for reference when diagnosing)
- Each theme on: Dashboard, Banking, Invoices, an invoice, Bills, Reports, Settings. Fonts look the same as
  the screenshots (not Arial/Segoe), also with the PC offline.
- Banking > For review: press J to move, A to approve, E to open, X to exclude.
- Dashboard Approve button approves a suggested bank transaction and the counts update.
- Plans and modules: set a client company's Default look to Executive; its owner (who hasn't chosen a look)
  sees Executive.
- Everything from v0.8.0 still works (plans/modules, Microsoft 365 email, invoices, payments, bills).

Deliver: portable-output\FMFinance.exe, the build log, the test summary, selftest.txt and the upgrade
check result.
