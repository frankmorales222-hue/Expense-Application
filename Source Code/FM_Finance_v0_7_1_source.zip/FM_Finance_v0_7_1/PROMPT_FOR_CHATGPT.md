# F&M Finance v0.7.1: build handoff for ChatGPT

I'm attaching FM_Finance_v0_7_1_source.zip. The source has been reviewed and tested.
Your job is packaging and build verification only: do NOT change application code (backend/app,
frontend/src, backend/alembic, backend/tests). If something fails, show me the exact error and
propose the smallest packaging-only fix before applying it.

## Build (same process as v0.7.0)
1. 64-bit Python 3.12 and Node 20+.
2. Frontend: `npm ci` then `npm run build` in frontend\.
3. Install backend\requirements-portable.txt exactly as pinned, plus pyinstaller==6.22.3, pytest==8.3.4,
   httpx==0.28.1. No --upgrade.
   No new packages since v0.7.0 (fpdf2, fonttools, defusedxml and cryptography are already pinned).
   Microsoft 365 sign-in uses only the Python standard library.
4. Tests: in backend\, set TEST_DATABASE_URL=sqlite:///data/fm_finance_test.db and run pytest -q.
   Expected: 129 passed, 1 skipped.
5. Build with packaging\fm_finance_portable.spec. The spec now also bundles fpdf and fontTools
   (collect_all) and lists the new modules as hidden imports: app.schema_sales, the app.invoicing
   package (pdf, mailer, secretbox, service, microsoft, outbox), app.schema_email_oauth,
   app.routers.invoices, payments, items, sales and mail, and cryptography.fernet.
6. `FMFinance.exe --selftest` must write selftest.txt starting with PASS. It now also contains
   `invoice_pdf: ok` and `mail_password_encryption: ok`; if either says ERROR, fpdf2 or cryptography
   wasn't bundled (packaging fix only).
7. Start the EXE from an empty folder with a prepared .env and check /api/health: version 0.7.1,
   database ok, storage ok.
Version is 0.7.1 everywhere. Do not change it.

## Upgrade check
Copy my v0.7.0 data folder next to the new EXE (a COPY), start it, sign in and check:
- The log shows no errors and the database is at revision 0016_sqlite_email_oauth.
- Settings > Books still says "Your books are in balance"; invoices and customers are unchanged.
- Settings > Email shows three choices: Microsoft 365 / Outlook (works with MFA), Gmail, Other mail server.
- The EXE can reach https://login.microsoftonline.com and https://graph.microsoft.com (no proxy errors).

## What changed in v0.7.1
"Connect Microsoft 365" in Settings > Email: sign in on Microsoft's page (device code, works with MFA),
invoices are sent through Microsoft Graph and saved in Sent Items. The SMTP option stays for Gmail and
other servers. Small migration 0016 (SQLite) / 0017 (PostgreSQL): four columns on email_settings.

## Smoke test I will run on Windows (for reference when diagnosing)
- Settings > Email: paste my Entra app (client) ID, Connect Microsoft 365, enter the code at
  microsoft.com/devicelogin, sign in with MFA; the page shows "Connected"; Send test arrives.
- Products and services: add "Managed IT – per user" at $85.
- Create an invoice for a customer, Save and send: the email arrives with Invoice-1001.pdf attached.
- Receive payment for it, matched to an imported deposit: the invoice shows Paid and the deposit is
  approved in Banking; the Balance sheet still balances.
- Reports > A/R aging and Sales by customer show the right amounts.
- Companies, team roles, bills, bill import, logo and Exit app still work.

Deliver: portable-output\FMFinance.exe, the build log, the test summary, selftest.txt and the upgrade
check result.
