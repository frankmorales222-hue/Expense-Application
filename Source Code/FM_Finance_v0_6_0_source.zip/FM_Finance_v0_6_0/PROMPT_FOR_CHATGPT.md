# F&M Finance v0.6.0: build handoff for ChatGPT

I'm attaching FM_Finance_v0_6_0_source.zip. The source has been reviewed and tested.
Your job is packaging and build verification only: do NOT change application code (backend/app,
frontend/src, backend/alembic, backend/tests). If something fails, show me the exact error and
propose the smallest packaging-only fix before applying it.

## Build (same process as v0.5.1)
1. 64-bit Python 3.12 and Node 20+.
2. Frontend: `npm ci` then `npm run build` in frontend\.
3. Install backend\requirements-portable.txt exactly as pinned, plus pyinstaller==6.22.3, pytest==8.3.4,
   httpx==0.28.1. No --upgrade. (No new dependencies in this version.)
4. Tests: in backend\, set TEST_DATABASE_URL=sqlite:///data/fm_finance_test.db and run pytest -q.
   Expected: 106 passed, 1 skipped.
5. Build with packaging\fm_finance_portable.spec. The new modules (the app.ledger package,
   app.schema_ledger, app.routers.bills, app.routers.ledger, app.routers.lines) are listed as hidden
   imports and also picked up by collect_submodules("app").
6. `FMFinance.exe --selftest` must write selftest.txt starting with PASS.
7. Start the EXE from an empty folder with a prepared .env and check /api/health: version 0.6.0,
   database ok, storage ok.
Version is 0.6.0 everywhere. Do not change it.

## Upgrade check (important: this version changes the database)
Copy a v0.5.1 data folder (with real expenses and bank transactions) next to the new EXE, start it,
then sign in and check:
- The server log (logs folder) shows "Built the books for <company> from N existing records" for each company,
  with no errors.
- Settings > Books says "Your books are in balance." (or GET /api/ledger/status returns balanced: true
  and unbalanced_entries: 0).
- Expenses still list every old expense; each opens with one category line; linked ones show the bank
  account under Payment account.
Do this on a COPY of the data folder. The migration can't be undone automatically.

## What changed in v0.6.0
Double-entry books for each company: chart of accounts with registers, automatic posting of
expenses, bills, bill payments, approved bank transactions and opening balances; QuickBooks-style
expense form (payment account, split category lines, billable + customer); Bills with terms, due
dates and Pay bill matched to the bank charge; journal entries; Profit and loss, Balance sheet and
Trial balance reports; closing date. Database migration 0012 (SQLite) / 0013 (PostgreSQL).

## Smoke test I will run on Windows (for reference when diagnosing)
- Add an expense with two category lines paid from a bank account; it shows "Split (2 lines)" in the
  list and both categories move on the Profit and loss.
- Enter a bill with Net 30; it appears under Bills > Unpaid and in Accounts Payable on the Balance
  sheet. Pay it and match the bank charge; the bill shows Paid and the charge isn't counted twice.
- Chart of accounts: open Checking's register; the running balance matches the Accounts page.
- Journal entries: a balanced entry saves; an unbalanced one is refused.
- Set a closing date in Settings > Books, then try to edit an older expense: it's refused.
- Balance sheet: total assets equals total liabilities and equity.
- Companies, team roles, bill import, banking, logo and Exit app still work.

Deliver: portable-output\FMFinance.exe, the build log, the test summary and the upgrade check result.
