"""Pydantic request/response models.

Money is stored as Decimal and serialized to JSON as a number (never a string),
which avoids the string-concatenation bug in the original prototype.
"""

from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, PlainSerializer, field_validator

Money = Annotated[Decimal, PlainSerializer(lambda v: float(v), return_type=float, when_used="json")]
PositiveMoney = Annotated[Decimal, Field(gt=0, max_digits=12, decimal_places=2)]

ExpenseStatus = Literal["pending", "approved", "paid", "rejected"]
PaymentMethod = Literal["business_card", "business_bank", "personal_card", "cash", "other"]


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ---------- Auth ----------
class LoginIn(BaseModel):
    email: str = Field(min_length=3, max_length=255)
    password: str = Field(min_length=1, max_length=256)


class ChangePasswordIn(BaseModel):
    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=10, max_length=256)


class UserOut(BaseModel):
    """The signed-in user and the company they're working in."""

    id: uuid.UUID
    email: str
    name: str
    # Permission name in the current company: admin (owner), approver (accountant/bookkeeper),
    # submitter (employee), viewer, or "none" when the user has no company yet.
    role: str
    company_role: str | None = None
    company_id: uuid.UUID | None = None
    company_name: str | None = None
    company_count: int = 0
    is_platform_admin: bool = False
    is_reseller_admin: bool = False


# ---------- Categories / vendors ----------
CategoryKind = Literal["expense", "income", "equity"]


class CategoryOut(ORM):
    id: uuid.UUID
    code: str
    name: str
    approval_threshold: Money | None
    is_active: bool
    sort_order: int
    kind: CategoryKind
    tax_line: str | None


class CategoryIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    approval_threshold: Annotated[Decimal, Field(ge=0, max_digits=12, decimal_places=2)] | None = None
    sort_order: int | None = None
    kind: CategoryKind = "expense"
    tax_line: str | None = Field(default=None, max_length=100)

    @field_validator("name")
    @classmethod
    def strip_name(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Name is required")
        return v


class CategoryUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    approval_threshold: Annotated[Decimal, Field(ge=0, max_digits=12, decimal_places=2)] | None = None
    clear_threshold: bool = False
    is_active: bool | None = None
    sort_order: int | None = None
    kind: CategoryKind | None = None
    tax_line: str | None = Field(default=None, max_length=100)


class VendorOut(ORM):
    id: uuid.UUID
    name: str


class VendorDetail(ORM):
    id: uuid.UUID
    name: str
    match_key: str | None
    default_category_id: uuid.UUID | None
    is_1099: bool


class VendorUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    default_category_id: uuid.UUID | None = None
    clear_default_category: bool = False
    is_1099: bool | None = None
    match_key: str | None = Field(default=None, max_length=255)


# ---------- Expenses ----------
class LineIn(BaseModel):
    """One category split of an expense or bill (QuickBooks "category details")."""

    category_id: uuid.UUID
    description: str | None = Field(default=None, max_length=500)
    amount: PositiveMoney
    billable: bool = False
    customer_id: uuid.UUID | None = None

    @field_validator("description")
    @classmethod
    def blank_none(cls, v: str | None) -> str | None:
        return (v or "").strip() or None


class LineOut(BaseModel):
    id: uuid.UUID
    category_id: uuid.UUID
    category_name: str
    description: str | None
    amount: Money
    billable: bool
    customer_id: uuid.UUID | None
    customer_name: str | None


class ExpenseIn(BaseModel):
    """Send `lines` (one or more category splits). The single category_id + amount form from earlier
    versions is still accepted and becomes one line."""

    expense_date: date
    vendor_name: str | None = Field(default=None, max_length=255)
    category_id: uuid.UUID | None = None
    description: str = Field(min_length=1, max_length=500)
    amount: PositiveMoney | None = None
    lines: list[LineIn] | None = Field(default=None, max_length=50)
    payment_account_id: uuid.UUID | None = None
    payment_method: PaymentMethod | None = None
    is_reimbursable: bool = False
    notes: str | None = Field(default=None, max_length=5000)
    invoice_number: str | None = Field(default=None, max_length=100)
    due_date: date | None = None

    @field_validator("description")
    @classmethod
    def strip_description(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Description is required")
        return v

    @field_validator("vendor_name", "notes", "invoice_number")
    @classmethod
    def blank_to_none(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip()
        return v or None

    def resolved_lines(self) -> list[LineIn]:
        if self.lines:
            return self.lines
        if self.category_id is None or self.amount is None:
            raise ValueError("Add at least one line with a category and amount")
        return [LineIn(category_id=self.category_id, amount=self.amount)]


class StatusIn(BaseModel):
    status: ExpenseStatus
    note: str | None = Field(default=None, max_length=1000)
    # For "paid" on an expense someone paid personally: the account they were reimbursed from.
    payment_account_id: uuid.UUID | None = None


class ReceiptOut(ORM):
    id: uuid.UUID
    original_filename: str
    content_type: str
    size_bytes: int
    uploaded_at: datetime


class AuditOut(BaseModel):
    id: uuid.UUID
    action: str
    user_name: str | None
    changes: dict[str, Any] | None
    created_at: datetime


class ExpenseListItem(BaseModel):
    id: uuid.UUID
    payment_account_id: uuid.UUID | None = None
    payment_account_name: str | None = None
    line_count: int = 1
    expense_date: date
    vendor_name: str | None
    category_id: uuid.UUID
    category_name: str
    description: str
    amount: Money
    currency: str
    payment_method: str | None
    is_reimbursable: bool
    status: str
    receipt_count: int
    created_at: datetime


class ExpenseDetail(ExpenseListItem):
    lines: list[LineOut] = []
    notes: str | None
    invoice_number: str | None = None
    due_date: date | None = None
    bank_transaction_id: uuid.UUID | None = None
    approved_at: datetime | None
    paid_at: datetime | None
    receipts: list[ReceiptOut]
    history: list[AuditOut]
    allowed_transitions: list[str]


class ExpensePage(BaseModel):
    items: list[ExpenseListItem]
    total: int
    total_amount: Money
    page: int
    page_size: int


# ---------- Reports ----------
class NameAmount(BaseModel):
    key: str
    label: str
    amount: Money
    count: int


class SummaryOut(BaseModel):
    date_from: date | None
    date_to: date | None
    total_spent: Money
    expense_count: int
    pending_count: int
    pending_amount: Money
    reimbursable_owed: Money
    by_status: list[NameAmount]
    by_category: list[NameAmount]
    by_month: list[NameAmount]


class AppSettingsOut(BaseModel):
    version: str
    currency: str
    approval_required: bool
    default_approval_threshold: Money
    max_receipt_mb: int
    desktop_mode: bool
    receipt_storage: str
    database: str


# ---------- Phase 1: banking ----------
AccountKind = Literal["checking", "savings", "credit_card", "cash", "other"]
ReviewStatus = Literal["unreviewed", "approved", "excluded"]
SignedMoney = Annotated[Decimal, Field(max_digits=12, decimal_places=2)]


def _strip_required(v: str) -> str:
    v = " ".join(v.split())
    if not v:
        raise ValueError("Required")
    return v


class CompanyOut(ORM):
    id: uuid.UUID
    name: str
    legal_name: str | None
    base_currency: str
    fiscal_year_start_month: int
    has_logo: bool = False
    logo_version: int = 0


class BrandingOut(BaseModel):
    """Shown before sign-in: name and logo only."""

    name: str
    has_logo: bool
    logo_version: int
    company_id: uuid.UUID | None = None


class CompanyIn(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    legal_name: str | None = Field(default=None, max_length=255)
    fiscal_year_start_month: int = Field(default=1, ge=1, le=12)

    _name = field_validator("name")(classmethod(lambda cls, v: _strip_required(v)))


class AccountIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    kind: AccountKind
    institution: str | None = Field(default=None, max_length=120)
    last4: str | None = Field(default=None, pattern=r"^[0-9]{4}$")
    opening_balance: SignedMoney = Decimal("0")
    opening_date: date | None = None
    is_active: bool = True

    _name = field_validator("name")(classmethod(lambda cls, v: _strip_required(v)))

    @field_validator("institution", "last4", mode="before")
    @classmethod
    def blank_none(cls, v: object) -> object:
        return None if isinstance(v, str) and not v.strip() else v


class AccountOut(ORM):
    id: uuid.UUID
    name: str
    kind: AccountKind
    institution: str | None
    last4: str | None
    currency: str
    opening_balance: Money
    opening_date: date | None
    is_active: bool
    balance: Money = Decimal("0")
    unreviewed_count: int = 0
    transaction_count: int = 0
    has_csv_profile: bool = False


class CustomerIn(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    email: str | None = Field(default=None, max_length=255)
    notes: str | None = Field(default=None, max_length=5000)
    is_active: bool = True

    _name = field_validator("name")(classmethod(lambda cls, v: _strip_required(v)))


class CustomerOut(ORM):
    id: uuid.UUID
    name: str
    email: str | None
    notes: str | None
    is_active: bool


class CsvMapping(BaseModel):
    date_column: int | None = None
    description_column: int | None = None
    amount_column: int | None = None
    debit_column: int | None = None
    credit_column: int | None = None
    invert_amounts: bool = False
    date_format: str | None = Field(default=None, max_length=20)


class PreviewRow(BaseModel):
    line: int
    txn_date: date | None
    amount: Money | None
    description: str
    error: str | None


class ImportPreviewOut(BaseModel):
    source: str
    filename: str
    total_rows: int
    valid_rows: int
    invalid_rows: int
    date_from: date | None
    date_to: date | None
    money_in: Money
    money_out: Money
    rows: list[PreviewRow]
    headers: list[str] = []
    sample: list[list[str]] = []
    mapping: CsvMapping | None = None
    problems: list[str] = []
    file_account_last4: str | None = None
    previously_imported: bool = False


class ImportBatchOut(ORM):
    id: uuid.UUID
    account_id: uuid.UUID
    account_name: str = ""
    source: str
    filename: str
    rows_total: int
    rows_imported: int
    rows_duplicate: int
    rows_invalid: int
    rows_flagged: int
    status: str
    created_at: datetime
    approved_count: int = 0


class PeerOut(BaseModel):
    id: uuid.UUID
    account_id: uuid.UUID
    account_name: str
    txn_date: date
    amount: Money
    description: str
    review_status: str


class TransactionOut(BaseModel):
    id: uuid.UUID
    account_id: uuid.UUID
    account_name: str
    bill_id: uuid.UUID | None = None  # this charge is the payment of a bill
    account_kind: str
    txn_date: date
    amount: Money
    description: str
    normalized: str
    memo: str | None
    source: str
    review_status: ReviewStatus
    category_id: uuid.UUID | None
    category_name: str | None
    vendor_id: uuid.UUID | None
    vendor_name: str | None
    customer_id: uuid.UUID | None
    customer_name: str | None
    suggested_category_id: uuid.UUID | None
    suggested_category_name: str | None
    suggested_vendor_name: str | None
    confidence: int
    suggestion_reason: str | None
    is_transfer: bool
    transfer_peer: PeerOut | None
    duplicate_of: PeerOut | None
    expense_id: uuid.UUID | None
    receipt_status: Literal["attached", "missing", "not_needed"]
    approved_at: datetime | None


class TransactionPage(BaseModel):
    items: list[TransactionOut]
    total: int
    page: int
    page_size: int
    counts: dict[str, int]
    total_in: Money
    total_out: Money


class TransactionUpdate(BaseModel):
    """Only fields that are sent are changed; send null to clear."""

    category_id: uuid.UUID | None = None
    vendor_name: str | None = Field(default=None, max_length=255)
    customer_id: uuid.UUID | None = None
    memo: str | None = Field(default=None, max_length=5000)
    expense_id: uuid.UUID | None = None


class ManualTransactionIn(BaseModel):
    account_id: uuid.UUID
    txn_date: date
    amount: SignedMoney
    description: str = Field(min_length=1, max_length=500)
    category_id: uuid.UUID | None = None
    vendor_name: str | None = Field(default=None, max_length=255)
    customer_id: uuid.UUID | None = None
    memo: str | None = Field(default=None, max_length=5000)

    _desc = field_validator("description")(classmethod(lambda cls, v: _strip_required(v)))

    @field_validator("amount")
    @classmethod
    def nonzero(cls, v: Decimal) -> Decimal:
        if v == 0:
            raise ValueError("Amount can't be zero")
        return v


class BulkIds(BaseModel):
    ids: list[uuid.UUID] = Field(min_length=1, max_length=500)


class ApproveConfidentIn(BaseModel):
    account_id: uuid.UUID | None = None
    min_confidence: int = Field(default=90, ge=50, le=100)


class BulkResult(BaseModel):
    approved: int
    skipped: int
    messages: list[str] = []


class LinkTransferIn(BaseModel):
    peer_id: uuid.UUID


class CandidatesOut(BaseModel):
    transfers: list[PeerOut]
    expenses: list[ExpenseListItem]



# ---------- v0.4.0: bill import ----------
class BillCapabilities(BaseModel):
    ocr: bool
    ai_mode: str
    ai_requested: str
    ai_key_set: bool
    ai_model: str
    formats: list[str]


class BankMatch(BaseModel):
    id: uuid.UUID
    account_name: str
    txn_date: date
    description: str


class BillExtractOut(BaseModel):
    filename: str
    method: Literal["text", "ocr", "ai"]
    vendor_name: str | None
    expense_date: date | None
    due_date: date | None
    amount: Money | None
    invoice_number: str | None
    description: str | None
    currency: str
    category_id: uuid.UUID | None
    category_reason: str
    confidence: dict[str, float]
    sources: dict[str, str]
    confident: bool
    known_vendor: bool
    warnings: list[str]
    attachments: list[str]
    text_preview: str
    duplicates: list[ExpenseListItem]
    bank_match: BankMatch | None



# ---------- v0.5.0: multi-company ----------
CompanyRole = Literal["owner", "accountant", "bookkeeper", "employee", "viewer"]


class CompanyListItem(BaseModel):
    id: uuid.UUID
    name: str
    role: CompanyRole
    via_reseller: bool
    reseller_id: uuid.UUID | None
    reseller_name: str | None
    has_logo: bool
    logo_version: int
    is_current: bool


class CompanyCreateIn(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    legal_name: str | None = Field(default=None, max_length=255)
    reseller_id: uuid.UUID | None = None
    fiscal_year_start_month: int = Field(default=1, ge=1, le=12)

    _name = field_validator("name")(classmethod(lambda cls, v: _strip_required(v)))


class MemberOut(BaseModel):
    user_id: uuid.UUID
    name: str
    email: str
    role: CompanyRole
    via_reseller: bool
    is_you: bool
    is_active: bool


class MemberIn(BaseModel):
    email: str = Field(min_length=3, max_length=255, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    name: str | None = Field(default=None, max_length=255)
    role: CompanyRole


class MemberRoleIn(BaseModel):
    role: CompanyRole


class MemberAdded(BaseModel):
    member: MemberOut
    temporary_password: str | None = None


class ResellerAdminOut(BaseModel):
    user_id: uuid.UUID
    name: str
    email: str


class ResellerOut(BaseModel):
    id: uuid.UUID
    name: str
    is_active: bool
    company_count: int
    admins: list[ResellerAdminOut]


class ResellerIn(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    is_active: bool = True

    _name = field_validator("name")(classmethod(lambda cls, v: _strip_required(v)))


class ResellerAdminIn(BaseModel):
    email: str = Field(min_length=3, max_length=255, pattern=r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    name: str | None = Field(default=None, max_length=255)


class ResellerAdminAdded(BaseModel):
    admin: ResellerAdminOut
    temporary_password: str | None = None


# ---------- v0.6.0: bills ----------
BillTerms = Literal["due_on_receipt", "net_15", "net_30", "net_45", "net_60"]
BillStatus = Literal["open", "partial", "paid", "overdue"]


class BillIn(BaseModel):
    vendor_name: str = Field(min_length=1, max_length=255)
    bill_date: date
    terms: BillTerms | None = None
    due_date: date | None = None  # defaults from terms (or the bill date)
    bill_number: str | None = Field(default=None, max_length=100)
    memo: str | None = Field(default=None, max_length=5000)
    lines: list[LineIn] = Field(min_length=1, max_length=50)

    _vendor = field_validator("vendor_name")(classmethod(lambda cls, v: _strip_required(v)))

    @field_validator("bill_number", "memo")
    @classmethod
    def blank_none(cls, v: str | None) -> str | None:
        return (v or "").strip() or None


class BillPaymentOut(BaseModel):
    id: uuid.UUID
    payment_date: date
    account_id: uuid.UUID
    account_name: str
    amount: Money
    memo: str | None
    transaction_id: uuid.UUID | None


class BillAttachmentOut(ORM):
    id: uuid.UUID
    original_filename: str
    content_type: str
    size_bytes: int
    uploaded_at: datetime


class BillListItem(BaseModel):
    id: uuid.UUID
    vendor_id: uuid.UUID
    vendor_name: str
    bill_date: date
    due_date: date
    terms: str | None
    bill_number: str | None
    total: Money
    paid: Money
    balance: Money
    status: BillStatus
    attachment_count: int


class BillDetail(BillListItem):
    memo: str | None
    lines: list[LineOut]
    payments: list[BillPaymentOut]
    attachments: list[BillAttachmentOut]


class BillPage(BaseModel):
    items: list[BillListItem]
    total_open: Money
    total_overdue: Money


class BillPaymentIn(BaseModel):
    payment_date: date
    account_id: uuid.UUID
    amount: PositiveMoney
    memo: str | None = Field(default=None, max_length=500)
    transaction_id: uuid.UUID | None = None


# ---------- v0.6.0: ledger ----------
AccountType = Literal["asset", "liability", "equity", "income", "expense"]


class LedgerAccountOut(BaseModel):
    id: uuid.UUID
    code: str | None
    name: str
    type: AccountType
    detail_type: str
    system_key: str | None
    description: str | None
    is_active: bool
    balance: Money
    linked_to: Literal["category", "bank", "system", "none"]
    category_id: uuid.UUID | None = None
    bank_account_id: uuid.UUID | None = None


class LedgerAccountIn(BaseModel):
    """Accounts made here are for journal entries and future features (loans, equipment, owner's capital).
    Expense and income accounts are created through Settings > Categories so they can be chosen on
    expenses and in Banking; bank and card accounts through Accounts."""

    code: str | None = Field(default=None, max_length=20)
    name: str = Field(min_length=1, max_length=150)
    type: AccountType
    detail_type: str = Field(min_length=1, max_length=30)
    description: str | None = Field(default=None, max_length=500)
    is_active: bool = True

    _name = field_validator("name")(classmethod(lambda cls, v: _strip_required(v)))


class RegisterLine(BaseModel):
    entry_id: uuid.UUID
    entry_date: date
    source_type: str
    source_id: uuid.UUID | None
    number: str | None
    memo: str | None
    description: str | None
    other_accounts: str
    debit: Money
    credit: Money
    balance: Money


class RegisterOut(BaseModel):
    account: LedgerAccountOut
    lines: list[RegisterLine]
    opening_balance: Money


class JournalLineIn(BaseModel):
    account_id: uuid.UUID
    debit: Annotated[Decimal, Field(ge=0, max_digits=12, decimal_places=2)] = Decimal("0")
    credit: Annotated[Decimal, Field(ge=0, max_digits=12, decimal_places=2)] = Decimal("0")
    description: str | None = Field(default=None, max_length=500)
    customer_id: uuid.UUID | None = None
    vendor_name: str | None = Field(default=None, max_length=255)


class JournalEntryIn(BaseModel):
    entry_date: date
    number: str | None = Field(default=None, max_length=30)
    memo: str | None = Field(default=None, max_length=500)
    lines: list[JournalLineIn] = Field(min_length=2, max_length=100)


class JournalLineOut(BaseModel):
    account_id: uuid.UUID
    account_name: str
    debit: Money
    credit: Money
    description: str | None
    customer_id: uuid.UUID | None
    vendor_name: str | None


class JournalEntryOut(BaseModel):
    id: uuid.UUID
    entry_date: date
    source_type: str
    source_id: uuid.UUID | None
    number: str | None
    memo: str | None
    total: Money
    lines: list[JournalLineOut]
    editable: bool


class ReportRow(BaseModel):
    account_id: uuid.UUID
    name: str
    code: str | None
    amount: Money


class ReportSection(BaseModel):
    key: str
    label: str
    rows: list[ReportRow]
    total: Money


class ProfitLossOut(BaseModel):
    date_from: date
    date_to: date
    sections: list[ReportSection]
    gross_profit: Money
    net_operating_income: Money
    net_income: Money


class BalanceSheetOut(BaseModel):
    as_of: date
    sections: list[ReportSection]
    total_assets: Money
    total_liabilities_and_equity: Money
    balanced: bool


class TrialBalanceRow(BaseModel):
    account_id: uuid.UUID
    name: str
    code: str | None
    type: str
    debit: Money
    credit: Money


class TrialBalanceOut(BaseModel):
    as_of: date
    rows: list[TrialBalanceRow]
    total_debit: Money
    total_credit: Money


class ClosingDateIn(BaseModel):
    closing_date: date | None = None


class BooksStatusOut(BaseModel):
    closing_date: date | None
    total_debit: Money
    total_credit: Money
    balanced: bool
    unbalanced_entries: int
    payment_account_not_set: int
